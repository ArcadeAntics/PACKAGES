# splitter.inator2 <- function (x, sep = " ",
#     sepchar = nchar(sep, type = "bytes", keepNA = FALSE),
#     w = nchar(x, type = "width"))
# {
#     if (identical(sep, "\n"))
#         return(x)
#     .Call(C_splitter.inator
# }
