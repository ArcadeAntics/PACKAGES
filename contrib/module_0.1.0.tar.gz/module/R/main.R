.onLoad <- function (libname, pkgname)
.External2(.C_onLoad, libname, pkgname)


.onUnload <- function (libpath)
.External2(.C_onUnload, libpath)


isModuleEnv <- function (mod)
.External2(.C_isModuleEnv, mod)


loadedModules <- function ()
names(.External2(.C_getModuleRegistry))


.getModuleInfo <- function (mod, which)
{
    mod[[".__MODULE__."]][[which]]
}


getModuleInfo <- function (mod, which)
{
    mod <- asModule(mod)
    get(which, envir = mod[[".__MODULE__."]])
}


setModuleInfo <- function (mod, which, value)
{
    mod <- asModule(mod)
    info <- mod[[".__MODULE__."]]
    info[[which]] <- val
}


getModuleExports <- function (mod)
{
    mod <- asModule(mod)
    names(.getModuleInfo(mod, "exports"))
}


getModuleImports <- function (mod)
{
    mod <- asModule(mod)
    .getModuleInfo(mod, "imports")
}


getModuleName <- function (mod)
{
    mod <- asModule(mod)
    .getModuleInfo(mod, "spec")["name"]
}


getModuleUsers <- function (mod)
{
    modname <- getModuleName(asModule(mod))
    users <- character()
    for (n in loadedModules()) {
        inames <- names(getModuleImports(n))
        if (match(modname, inames, 0L))
            users <- c(n, users)
    }
    users
}


getModuleVersion <- function (mod)
{
    mod <- asModule(mod)
    .getModuleInfo(mod, "spec")["version"]
}


moduleExport <- function (mod, vars)
{
    moduleIsSealed <- function(mod) environmentIsLocked(mod)
    if (moduleIsSealed(mod))
        stop("cannot add to exports of a sealed module")
    mod <- asModule(mod)
    info <- mod[[".__MODULE__."]]
    info$exportPatterns <- as.character(info$exportPatterns)
    if (length(vars)) {
        addExports <- function(mod, new) {
            exports <- .getModuleInfo(mod, "exports")
            expnames <- names(new)
            objs <- names(exports)
            ex <- expnames %in% objs
            if (any(ex))
                warning(sprintf(ngettext(sum(ex), "previous export '%s' is being replaced",
                    "previous exports '%s' are being replaced", domain = "R"),
                    paste(sQuote(expnames[ex]), collapse = ", ")),
                    call. = FALSE, domain = NA)
            list2env(as.list(new), exports)
        }
        makeImportExportNames <- function(spec) {
            old <- as.character(spec)
            new <- names(spec)
            if (is.null(new))
                new <- old
            else {
                change <- !nzchar(new)
                new[change] <- old[change]
            }
            names(old) <- new
            old
        }
        new <- makeImportExportNames(unique(vars))
        undef <- new[!new %in% names(mod)]
        undef <- undef[!vapply(undef, exists, NA, envir = mod)]
        if (length(undef)) {
            print(undef)
            undef <- do.call("paste", as.list(c(undef, sep = ", ")))
            undef <- sub("^\\.__C__", "class ", undef)
            stop(gettextf("undefined exports: %s", undef, domain = "R"), domain = NA)
        }
        addExports(mod, new)
    }
}


moduleImport <- function (self, ..., from = NULL, except = character(0L))
namespaceImport(self = self, ..., from = from, except = except)


moduleImportClasses <- function (self, mod, vars, from = NULL)
namespaceImportClasses(self, mod, vars, from)


moduleImportFrom <- function (self, mod, vars, generics, packages, from = "non-package environment",
    except = character(0L))
namespaceImportFrom(self, mod, vars, generics, packages, from, except)


moduleImportMethods <- function (self, mod, vars, from = NULL)
namespaceImportMethods(self, mod, vars, from)


unloadModule <- function (mod)
unloadNamespace(mod)


makeModule <- function (name, version = NULL)
{
    impenv <- new.env(parent = .BaseNamespaceEnv, hash = TRUE)
    attr(impenv, "name") <- paste0("imports:", name)
    env <- new.env(parent = impenv, hash = TRUE)
    attr(env, "name") <- paste0("namespace:", name)
    info <- new.env(hash = TRUE, parent = baseenv())
    env$.__MODULE__. <- info
    info$spec <- c(name = as.character(as.symbol(name)), version = as.character(version))
    info$exports <- new.env(hash = TRUE, parent = baseenv())
    info$exportPatterns <- NULL
    dimpenv <- new.env(parent = baseenv(), hash = TRUE)
    attr(dimpenv, "name") <- paste0("lazydata:", name)
    info$lazydata <- dimpenv
    info$imports <- list(base = TRUE)
    info$path <- name
    info$dynlibs <- NULL
    info$S3methods <- matrix(NA_character_, 0L, 4L)
    env$.__S3MethodsTable__. <- new.env(hash = TRUE, parent = baseenv())
    .External2(.C_registerModule, name, env)
    env
}


.loadingModuleInfo <- NULL


asChar <- function (cc)
{
    r <- as.character(cc)
    if (any(r == ""))
        stop(gettextf("empty name in directive '%s' in 'NAMESPACE' file",
            as.character(e[[1L]])), domain = NA)
    r
}


evalToChar <- function (cc)
{
    vars <- all.vars(cc)
    names(vars) <- vars
    as.character(eval(eval(call("substitute", cc, as.list(vars))), .GlobalEnv))
}


export <- function (...)
{
    if (!is.null(.loadingModuleInfo)) {
        e <- sys.call()
        exp <- e[-1L]
        exp <- structure(asChar(exp), names = names(exp))
        exp


        stoplist <- c(".__NAMESPACE__.", ".__S3MethodsTable__.",
            ".packageName", ".First.lib", ".onLoad", ".onAttach",
            ".conflicts.OK", ".noGenerics")
        exp <- exp[!exp %in% stoplist]
        exp


        moduleExport(.loadingModuleInfo[[1L]], exp)
    }
}


exportPattern <- function (...)
{
    if (!is.null(.loadingModuleInfo)) {
        e <- sys.call()
        pat <- asChar(e[-1L])
        pat


        .loadingModuleInfo


        moduleExport(.loadingModuleInfo, exp)
    }
}


exportClassPattern <- function (...)
{
    e <- sys.call()
    pat <- asChar(e[-1L])
    pat
}


exportClass <- exportClasses <- function (...)
{
    e <- sys.call()
    asChar(e[-1L])
}


exportMethods <- function (...)
{
    e <- sys.call()
    asChar(e[-1L])
}


import <- function (...)
{
    e <- sys.call()
    except <- e$except
    e$except <- NULL
    pkgs <- as.list(asChar(e[-1L]))
    if (!is.null(except)) {
        pkgs <- lapply(pkgs, list, except = evalToChar(except))
    }
    for (i in pkgs) {
        if (is.character(i))
            moduleImport(ns, from = getModuleName(ns))
        if (!is.null(i$except))
            moduleImport(ns, from = getModuleName(ns), except = i$except)
        else moduleImportFrom(ns, i[[2L]], from = getModuleName(ns))
    }
}


importFrom <- function (...)
{
    e <- sys.call()
    imp <- e[-1L]
    ivars <- imp[-1L]
    inames <- names(ivars)
    imp <- list(asChar(imp[1L]), structure(asChar(ivars), names = inames))
    list(imp)
}


importClassFrom <- importClassesFrom <- function (...)
{
    e <- sys.call()
    imp <- asChar(e[-1L])
    pkg <- imp[[1L]]
    impClasses <- imp[-1L]
    imp <- list(asChar(pkg), asChar(impClasses))
    list(imp)
}


importMethodsFrom <- function (...)
{
    e <- sys.call()
    imp <- asChar(e[-1L])
    pkg <- imp[[1L]]
    impClasses <- imp[-1L]
    imp <- list(asChar(pkg), asChar(impClasses))
    list(imp)
}


useDynLib <- function (...)
{
    e <- sys.call()
    dyl <- as.character(e[2L])
    dynlibs <- structure(dyl, names = ifelse(!is.null(names(e)) && nzchar(names(e)[2L]), names(e)[2L], ""))
    if (length(e) > 2L) {
        symNames <- as.character(e[-c(1L, 2L)])
        names(symNames) <- names(e[-c(1L, 2L)])
        if (length(names(symNames)) == 0L)
            names(symNames) <- symNames
        else if (any(w <- names(symNames) == "")) {
            names(symNames)[w] <- symNames[w]
        }
        dup <- duplicated(names(symNames))
        if (any(dup))
            warning(gettextf("duplicate symbol names %s in useDynLib(\"%s\")",
                paste(sQuote(names(symNames)[dup]), collapse = ", "), dyl),
                domain = NA, call. = FALSE)
        symNames <- symNames[!dup]
        fixes <- c("", "")
        idx <- match(".fixes", names(symNames))
        if (!is.na(idx)) {
            if (nzchar(symNames[idx])) {
                e <- parse(text = symNames[idx], keep.source = FALSE, srcfile = NULL)[[1L]]
                if (is.call(e))
                    val <- eval(e, .GlobalEnv)
                else val <- as.character(e)
                if (length(val))
                    fixes[seq_along(val)] <- val
            }
            symNames <- symNames[-idx]
        }
        useRegistration <- FALSE
        idx <- match(".registration", names(symNames))
        if (!is.na(idx)) {
            useRegistration <- as.logical(symNames[idx])
            symNames <- symNames[-idx]
        }
        nativeRoutines[[dyl]] <<- if (dyl %in% names(nativeRoutines)) mergeNativeRoutineMaps(nativeRoutines[[dyl]],
                                                                                             useRegistration, symNames, fixes) else nativeRoutineMap(useRegistration,
                                                                                                                                                     symNames, fixes)
    }
}


S3method <- function (...)
{
    e <- sys.call()
    spec <- e[-1L]
    if (length(spec) != 2L && length(spec) != 3L)
        stop(gettextf("bad 'S3method' directive: %s", deparse(e)), call. = FALSE, domain = NA)
    S3methods <- matrix(NA_character_, 1L, 4L)
    if (is.call(gen <- spec[[1L]]) && identical(as.character(gen[[1L]]), "::")) {
        pkg <- as.character(gen[[2L]])[1L]
        gen <- as.character(gen[[3L]])[1L]
        S3methods[1L, c(seq_along(spec), 4L)] <- c(gen, asChar(spec[-1L]), pkg)
    }
    else S3methods[1L, seq_along(spec)] <- asChar(spec)
    S3methods
}


tmp.must.be.a.character.string <- quote(
    if (!is.character(file) || length(file) != 1L)
        stop(gettextf("'%s' must be a character string", "file", domain = "R"), domain = NA)
)
tmp.normalize <- quote(
    if (grepl("^(ftp|ftps|http|https)://", file)) {
        file <- this.path:::.normalizeURL.1(file)
    }
    else {
        if (!this.path:::.is.abs.path(file))
            file <- this.path::ici(file, n = n + 1L)
        if (!file.exists(file))
            stop(gettextf("'%s' is not an existing file", "file", domain = "R"), domain = NA)
        file <- normalizePath(file, "/", TRUE)
    }
)


mynamespace <- environment()


.loadModule <- function (ofile, file, keep.source = getOption("keep.source.mods"), keep.parse.data = getOption("keep.parse.data.mods"))
{
    package <- as.character(as.symbol(file))
    loading <- dynGet("__module::ModulesLoading__", NULL)
    if (match(package, loading, 0L))
        stop("cyclic module dependency detected when loading ", sQuote(file),
             ", already loading ", paste(sQuote(loading), collapse = ", "),
             domain = NA)
    mod <- .External2(.C_getRegisteredModule, package)
    if (!is.null(mod)) {
        mod
    }
    else if (i <- match(".", this.path:::.relpath(mods <- loadedModules(), package, normalize = FALSE, normalize.path = FALSE), 0L)) {
        mod <- .External2(.C_getRegisteredModule, mods[[i]])
        .External2(.C_registerModule, package, mod)
        mod
    }
    else {
        mod <- makeModule(file)
        on.exit(.External2(.C_unregisterModule, package))
        mod$.packageName <- package


        old.loadingModuleInfo <- .loadingModuleInfo
        on.exit({
            (unlockBinding)(".loadingModuleInfo", mynamespace)
            assign(".loadingModuleInfo", old.loadingModuleInfo, envir = mynamespace, inherits = FALSE)
            lockBinding(".loadingModuleInfo", mynamespace)
        }, add = TRUE)
        (unlockBinding)(".loadingModuleInfo", mynamespace)
        assign(".loadingModuleInfo", list(mod, ModulesLoading = c(package, loading)),
            envir = mynamespace, inherits = FALSE)
        lockBinding(".loadingModuleInfo", mynamespace)


        keep.source <- as.logical(keep.source)
        keep.parse.data <- as.logical(keep.parse.data)
        oopt <- options(keep.source = keep.source, keep.parse.data = keep.parse.data,
            topLevelEnvironment = mod)
        on.exit(options(oopt), add = TRUE)
        if (keep.source) {
            lines <- readLines(file, warn = FALSE)
            srcfile <- srcfilecopy(file, lines, file.mtime(file), isFile = TRUE)
            exprs <- parse(text = lines, srcfile = srcfile, keep.source = TRUE)
        }
        else exprs <- parse(n = -1, file = file, srcfile = NULL, keep.source = FALSE)
        if (length(exprs)) {
            this.path::set.sys.path(file, ofile = ofile)
            for (i in seq_along(exprs)) eval(exprs[i], mod)
            this.path::unset.sys.path()
        }
        if (environmentIsLocked(mod))
            stop(gettextf("module %s is already sealed in 'loadModule'",
                sQuote(getModuleName(mod))), call. = FALSE, domain = NA)
        lockEnvironment(mod, TRUE)
        lockEnvironment(parent.env(mod), TRUE)


        (unlockBinding)(".loadingModuleInfo", mynamespace)
        assign(".loadingModuleInfo", old.loadingModuleInfo, envir = mynamespace, inherits = FALSE)
        lockBinding(".loadingModuleInfo", mynamespace)


        on.exit()
        mod
    }
}


loadModule <- eval(call("function", as.pairlist(alist(file = , keep.source = getOption("keep.source.mods"),
    keep.parse.data = getOption("keep.parse.data.mods"), n = 0L)), bquote(
{
    ofile <- file
    .(tmp.must.be.a.character.string)
    .(tmp.normalize)
    .loadModule(ofile, file, keep.source, keep.parse.data)
}
)))


getModule <- eval(call("function", as.pairlist(alist(file = , n = 0L)), bquote(
{
    ofile <- file
    .(tmp.must.be.a.character.string)
    mod <- .External2(.C_getRegisteredModule, file)
    if (!is.null(mod))
        mod
    else {
        .(tmp.normalize)
        mod <- .External2(.C_getRegisteredModule, file)
        if (!is.null(mod))
            mod
        else .loadModule(ofile, file)
    }
}
)))


rm(tmp.must.be.a.character.string)
rm(tmp.normalize)


isModule <- function (mod)
.External2(.C_isModuleEnv, mod)


asModule <- function (mod)
{
    if (is.character(mod))
        mod <- getModule(mod)
    else if (is.name(mod))
        mod <- getModule(as.character(mod))
    if (!isModule(mod))
        stop("not a module")
    else mod
}


S3method <- function (genname, class, method, envir = parent.frame())
{
    envir
    before.names <- names(envir)
    method
    after.names <- names(envir)
    if (is.function(method)) {
        new.names <- setdiff(after.names, before.names)
        if (i <- match(paste(genname, class, sep = "."), new.names, 0L))
            method <- new.names[[i]]
        else for (sym in new.names) {
            if (identical(method, get(sym, envir = envir))) {
                method <- sym
                break
            }
        }
    }
    if (!is.character(method))
        stop("bad method", domain = "R-base")
    registerS3method(genname, class, method, envir)
}


.importIntoEnv <- function (impenv, impnames, expenv, expnames)
.External2(.C_importIntoEnv, impenv, impnames, expenv, expnames)
