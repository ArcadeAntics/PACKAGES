.onLoad <- function (libname, pkgname)
.External2(.C_onLoad, libname, pkgname)


.onUnload <- function (libpath)
.External2(.C_onUnload, libpath)


isModule <- function (mod)
.External2(.C_isModuleEnv, mod)


loadedModules <- function ()
names(.External2(.C_getModuleRegistry))


.getModuleInfo <- function (mod, which)
{
    mod[[".__MODULE__."]][[which]]
}


getModuleInfo <- function (mod, which, n = 0L)
{
    mod <- asModule(mod, n = n + 1L)
    get(which, envir = mod[[".__MODULE__."]])
}


setModuleInfo <- function (mod, which, val, n = 0L)
{
    mod <- asModule(mod, n = n + 1L)
    info <- mod[[".__MODULE__."]]
    info[[which]] <- val
}


getModuleExports <- function (mod, n = 0L)
{
    mod <- asModule(mod, n = n + 1L)
    names(.getModuleInfo(mod, "exports"))
}


getModuleImports <- function (mod, n = 0L)
{
    mod <- asModule(mod, n = n + 1L)
    .getModuleInfo(mod, "imports")
}


getModuleName <- function (mod, n = 0L)
{
    mod <- asModule(mod, n = n + 1L)
    .getModuleInfo(mod, "spec")["name"]
}


getModuleUsers <- function (mod, n = 0L)
{
    modname <- getModuleName(asModule(mod, n = n + 1L))
    users <- character()
    for (n in loadedModules()) {
        inames <- names(getModuleImports(n))
        if (match(modname, inames, 0L))
            users <- c(n, users)
    }
    users
}


getModuleVersion <- function (mod, n = 0L)
{
    mod <- asModule(mod, n = n + 1L)
    .getModuleInfo(mod, "spec")["version"]
}


.asChar <- function (cc)
{
    r <- as.character(cc)
    if (any(r == ""))
        stop(gettextf("empty name in directive '%s'", ""))
    r
}


.evalToChar <- function (cc)
{
    vars <- all.vars(cc)
    names(vars) <- vars
    as.character(eval(eval(call("substitute", cc, as.list(vars))), .GlobalEnv))
}


.moduleExport <- function (mod, vars)
{
    moduleIsSealed <- function(mod) environmentIsLocked(mod)
    if (moduleIsSealed(mod))
        stop("cannot add to exports of a sealed module")
    mod <- asModule(mod)
    info <- mod[[".__MODULE__."]]
    info$exportPatterns <- as.character(info$exportPatterns)
    if (length(vars)) {
        addExports <- function(mod, new) {
            exports <- .getModuleInfo(mod, "exports")
            expnames <- names(new)
            objs <- names(exports)
            ex <- expnames %in% objs
            if (any(ex))
                warning(sprintf(ngettext(sum(ex), "previous export '%s' is being replaced",
                    "previous exports '%s' are being replaced", domain = "R"),
                    paste(sQuote(expnames[ex]), collapse = ", ")),
                    call. = FALSE, domain = NA)
            list2env(as.list(new), exports)
        }
        makeImportExportNames <- function(spec) {
            old <- as.character(spec)
            new <- names(spec)
            if (is.null(new))
                new <- old
            else {
                change <- !nzchar(new)
                new[change] <- old[change]
            }
            names(old) <- new
            old
        }
        new <- makeImportExportNames(unique(vars))
        undef <- new[!new %in% names(mod)]
        undef <- undef[!vapply(undef, exists, NA, envir = mod)]
        if (length(undef)) {
            print(undef)
            undef <- do.call("paste", as.list(c(undef, sep = ", ")))
            undef <- sub("^\\.__C__", "class ", undef)
            stop(gettextf("undefined exports: %s", undef, domain = "R"), domain = NA)
        }
        addExports(mod, new)
    }
}


export <- function (...)
{
    if (!is.null(loading <- dynGet("__module::ModulesLoading__", NULL))) {
        e <- sys.call()
        exp <- e[-1L]
        exp <- structure(.asChar(exp), names = names(exp))
        stoplist <- c(".__MODULE__.", ".__S3MethodsTable__.",
            ".packageName", ".First.lib", ".Last.lib", ".onLoad",
            ".onAttach", ".onDetach", ".conflicts.OK", ".noGenerics")
        exp <- exp[!exp %in% stoplist]
        mod <- .External2(.C_getRegisteredModule, loading[[1L]])
        if (!is.null(mod))
            .moduleExport(mod, exp)
    }
}


.moduleExportPattern <- function (mod, vars)
{
    moduleIsSealed <- function(mod) environmentIsLocked(mod)
    if (moduleIsSealed(mod))
        stop("cannot add to exports of a sealed module")
    mod <- asModule(mod)
    info <- mod[[".__MODULE__."]]
    info$exportPatterns <- c(vars, info$exportPatterns)
}


exportPattern <- function (...)
{
    if (!is.null(loading <- dynGet("__module::ModulesLoading__", NULL))) {
        e <- sys.call()
        pat <- .asChar(e[-1L])
        mod <- .External2(.C_getRegisteredModule, loading[[1L]])
        if (!is.null(mod))
            .moduleExportPattern(mod, exp)
    }
}


.moduleImportFrom <- function (self, mod, vars, generics, packages, from = "non-package environment",
    except = character(0L), n = 0L)
{
    addImports <- function(mod, from, what) {
        imp <- structure(list(what), names = getModuleName(from))
        imports <- getModuleImports(mod)
        setModuleInfo(mod, "imports", c(imports, imp))
    }
    moduleIsSealed <- function(mod) environmentIsLocked(mod)
    makeImportExportNames <- function(spec) {
        old <- as.character(spec)
        new <- names(spec)
        if (is.null(new))
            new <- old
        else {
            change <- !nzchar(new)
            new[change] <- old[change]
        }
        names(old) <- new
        old
    }
    whichMethodMetaNames <- function(impvars) {
        if (!.isMethodsDispatchOn())
            return(numeric())
        seq_along(impvars)[startsWith(impvars, ".__T__")]
    }
    if (is.character(self))
        self <- getModule(self, n = n + 1L)
    mod <- asModule(mod, n = n + 1L)
    modname <- getModuleName(mod)
    impvars <- if (missing(vars)) {
        stoplist <- c(".__MODULE__.", ".__S3MethodsTable__.",
            ".packageName", ".First.lib", ".Last.lib", ".onLoad",
            ".onAttach", ".onDetach", ".conflicts.OK", ".noGenerics")
        vars <- getModuleExports(mod)
        vars <- vars[!vars %in% stoplist]
    }
    else vars
    impvars <- impvars[!impvars %in% except]
    impvars <- makeImportExportNames(impvars)
    impnames <- names(impvars)
    if (anyDuplicated(impnames)) {
        stop(gettextf("duplicate import names %s", paste(sQuote(impnames[duplicated(impnames)]), collapse = ", ")), domain = NA)
    }
    if (isModule(self)) {
        if (moduleIsSealed(self))
            stop("cannot import into a sealed module")
        impenv <- parent.env(self)
        msg <- gettext("replacing previous import by %s when loading %s", domain = "R-base")
        register <- TRUE
    }
    else if (is.environment(self)) {
        impenv <- self
        msg <- gettext("replacing local value with import %s when loading %s", domain = "R-base")
        register <- FALSE
    }
    else stop("invalid import target")
    which <- whichMethodMetaNames(impvars)
    if (length(which)) {

    }
    for (n in impnames) if (!is.null(genImp <- impenv[[n]])) {
        if (identical(genImp, get0(n, mod, inherits = FALSE)))
            next
    }
    .External2(.C_importIntoEnv, impenv, impnames, mod, impvars)
    if (register)
        addImports(self, mod, if (missing(vars)) TRUE else impvars)
}


.moduleImport <- function (self, ..., from = NULL, except = character(0L))
for (mod in list(...)) .moduleImportFrom(self, asModule(mod), from = from, except = except)


.moduleImportClasses <- function (self, mod, vars, from = NULL)
{
    for (i in seq_along(vars)) vars[[i]] <- sprintf(".__%s__%s", "C", vars[[i]])
    .moduleImportFrom(self, asModule(mod), vars, from = from)
}


.moduleImportMethods <- function (self, mod, vars, from = NULL)
{

}


exportClassPattern <- function (...)
{
    e <- sys.call()
    pat <- .asChar(e[-1L])
    pat
}


exportClass <- exportClasses <- function (...)
{
    e <- sys.call()
    .asChar(e[-1L])
}


exportMethods <- function (...)
{
    e <- sys.call()
    .asChar(e[-1L])
}


import <- function (...)
{
    e <- sys.call()
    except <- e$except
    e$except <- NULL
    pkgs <- as.list(.asChar(e[-1L]))
    if (!is.null(except)) {
        pkgs <- lapply(pkgs, list, except = .evalToChar(except))
    }
    for (i in pkgs) {
        if (is.character(i))
            .moduleImport(ns, from = getModuleName(ns))
        if (!is.null(i$except))
            .moduleImport(ns, from = getModuleName(ns), except = i$except)
        else .moduleImportFrom(ns, i[[2L]], from = getModuleName(ns))
    }
}


importFrom <- function (...)
{
    e <- sys.call()
    imp <- e[-1L]
    ivars <- imp[-1L]
    inames <- names(ivars)
    imp <- list(.asChar(imp[1L]), structure(.asChar(ivars), names = inames))
    list(imp)
}


importClassFrom <- importClassesFrom <- function (...)
{
    e <- sys.call()
    imp <- .asChar(e[-1L])
    pkg <- imp[[1L]]
    impClasses <- imp[-1L]
    imp <- list(.asChar(pkg), .asChar(impClasses))
    list(imp)
}


importMethodsFrom <- function (...)
{
    e <- sys.call()
    imp <- .asChar(e[-1L])
    pkg <- imp[[1L]]
    impClasses <- imp[-1L]
    imp <- list(.asChar(pkg), .asChar(impClasses))
    list(imp)
}


useDynLib <- function (...)
{
    e <- sys.call()
    dyl <- as.character(e[2L])
    dynlibs <- structure(dyl, names = ifelse(!is.null(names(e)) && nzchar(names(e)[2L]), names(e)[2L], ""))
    if (length(e) > 2L) {
        symNames <- as.character(e[-c(1L, 2L)])
        names(symNames) <- names(e[-c(1L, 2L)])
        if (length(names(symNames)) == 0L)
            names(symNames) <- symNames
        else if (any(w <- names(symNames) == "")) {
            names(symNames)[w] <- symNames[w]
        }
        dup <- duplicated(names(symNames))
        if (any(dup))
            warning(gettextf("duplicate symbol names %s in useDynLib(\"%s\")",
                paste(sQuote(names(symNames)[dup]), collapse = ", "), dyl),
                domain = NA, call. = FALSE)
        symNames <- symNames[!dup]
        fixes <- c("", "")
        idx <- match(".fixes", names(symNames))
        if (!is.na(idx)) {
            if (nzchar(symNames[idx])) {
                e <- parse(text = symNames[idx], keep.source = FALSE, srcfile = NULL)[[1L]]
                if (is.call(e))
                    val <- eval(e, .GlobalEnv)
                else val <- as.character(e)
                if (length(val))
                    fixes[seq_along(val)] <- val
            }
            symNames <- symNames[-idx]
        }
        useRegistration <- FALSE
        idx <- match(".registration", names(symNames))
        if (!is.na(idx)) {
            useRegistration <- as.logical(symNames[idx])
            symNames <- symNames[-idx]
        }
        nativeRoutines[[dyl]] <<- if (dyl %in% names(nativeRoutines)) mergeNativeRoutineMaps(nativeRoutines[[dyl]],
                                                                                             useRegistration, symNames, fixes) else nativeRoutineMap(useRegistration,
                                                                                                                                                     symNames, fixes)
    }
}


tmp.must.be.a.character.string <- function (x = "file")
{
    x
    bquote(
        if (!is.character(.(as.symbol(x))) || length(.(as.symbol(x))) != 1L)
            stop(gettextf("'%s' must be a character string", .(as.character(x)), domain = "R"), domain = NA)
    )
}


tmp.normalize <- function (x = "file")
{
    x
    bquote(
        if (grepl("^(ftp|ftps|http|https)://", .(as.symbol(x)))) {
            .(as.symbol(x)) <- .normalizeURL.1(.(as.symbol(x)))
        }
        else {
            if (!.is.abs.path(.(as.symbol(x))))
                .(as.symbol(x)) <- ici(.(as.symbol(x)), n = n + 1L)
            if (dir.exists(.(as.symbol(x))))
                .(as.symbol(x)) <- path.join(.(as.symbol(x)), "__init__.R")
            if (!file.exists(.(as.symbol(x))))
                stop(gettextf("'%s' is not an existing file", .(as.character(x)), domain = "R"), domain = NA)
            .(as.symbol(x)) <- normalizePath(.(as.symbol(x)), "/", TRUE)
        }
    )
}


.moduleEvent <- function (file, event = "onLoad")
paste("UserHook", file, event, sep = "::")


moduleEvent <- eval(call("function", as.pairlist(alist(file = , event = c("onLoad", "onUnload"), n = 0L)), bquote(
{
    event <- match.arg(event)
    .(tmp.must.be.a.character.string("file"))
    .(tmp.normalize("file"))
    .moduleEvent(file, event)
}
)))


.loadModule <- function (ofile, file, keep.source = getOption("keep.source.mods"), keep.parse.data = getOption("keep.parse.data.mods"))
{
    package <- as.character(as.symbol(file))
    loading <- dynGet("__module::ModulesLoading__", NULL)
    if (match(package, loading, 0L))
        stop("cyclic module dependency detected when loading ", sQuote(file),
             ", already loading ", paste(sQuote(loading), collapse = ", "))
    `__module::ModulesLoading__` <- c(package, loading)
    mod <- .External2(.C_getRegisteredModule, package)
    if (!is.null(mod)) {
        mod
    }
    else if (i <- match(".", .relpath(mods <- loadedModules(), package, normalize = FALSE, normalize.path = FALSE), 0L)) {
        mod <- .External2(.C_getRegisteredModule, mods[[i]])
        .External2(.C_registerModule, package, mod)
        mod
    }
    else {
        runHook <- function(hookname, env) {
            if (!is.null(fun <- env[[hookname]])) {
                res <- tryCatch(fun(env), error = identity)
                if (inherits(res, "error")) {
                    stop(gettextf("%s failed in %s() for '%s', details:\n  call: %s\n  error: %s",
                        hookname, "loadModule", getModuleName(env), deparse(conditionCall(res))[1L],
                        conditionMessage(res)), call. = FALSE)
                }
            }
        }
        runUserHook <- function(file, mod) {
            files <- if (grepl("/__init__\\.[Rr]$", file))
                c(file, dirname2(file))
            else file
            x <- names(.userHooksEnv)
            x <- x[startsWith(x, "UserHook::")]
            x <- x[endsWith(x, "::onLoad")]
            x <- substr(x, 11L, nchar(x) - 8L)
            x <- x[grepl("^(ftp|ftps|http|https)://", x) | .is.abs.path(x)]
            x <- rev(x)
            for (file in files) {
                xx <- x["." == .relpath(x, file, normalize = FALSE, normalize.path = FALSE)]
                for (hookName in .moduleEvent(xx, "onLoad")) {
                    hooks <- getHook(hookName)
                    for (fun in hooks) try(fun(mod))
                }
            }
        }
        makeModule <- function(name, version = NULL) {
            impenv <- new.env(parent = .BaseNamespaceEnv, hash = TRUE)
            attr(impenv, "name") <- paste0("imports:", name)
            env <- new.env(parent = impenv, hash = TRUE)
            attr(env, "name") <- paste0("namespace:", name)
            info <- new.env(hash = TRUE, parent = baseenv())
            env$.__MODULE__. <- info
            info$spec <- c(name = as.character(as.symbol(name)), version = as.character(version))
            info$exports <- new.env(hash = TRUE, parent = baseenv())
            info$exportPatterns <- NULL
            dimpenv <- new.env(parent = baseenv(), hash = TRUE)
            attr(dimpenv, "name") <- paste0("lazydata:", name)
            info$lazydata <- dimpenv
            info$imports <- list(base = TRUE)
            info$path <- name
            info$dynlibs <- NULL
            info$S3methods <- matrix(NA_character_, 0L, 4L)
            env$.__S3MethodsTable__. <- new.env(hash = TRUE, parent = baseenv())
            .External2(.C_registerModule, name, env)
            env
        }
        sys.source2 <- function(ofile, file, envir, keep.source, keep.parse.data) {
            file <- set.sys.path(file, Function = c(".loadModule", "module"), ofile = ofile)
            keep.source <- as.logical(keep.source)
            keep.parse.data <- as.logical(keep.parse.data)
            oopt <- options(keep.source = keep.source, keep.parse.data = keep.parse.data,
                topLevelEnvironment = envir)
            on.exit(options(oopt))
            if (keep.source) {
                lines <- readLines(file, warn = FALSE)
                srcfile <- srcfilecopy(file, lines, file.mtime(file), isFile = TRUE)
                set.src.path(srcfile)
                exprs <- parse(text = lines, srcfile = srcfile, keep.source = TRUE)
            }
            else exprs <- parse(n = -1, file = file, srcfile = NULL, keep.source = FALSE)
            set.env.path(envir)
            if (length(exprs))
                for (i in seq_along(exprs)) eval(exprs[i], envir)
        }
        sealModule <- function(mod) {
            moduleIsSealed <- function(mod) environmentIsLocked(mod)
            mod <- asModule(mod)
            if (moduleIsSealed(mod))
                stop(gettextf("module %s is already sealed in 'loadModule'",
                    sQuote(getModuleName(mod))), call. = FALSE)
            lockEnvironment(mod, TRUE)
            lockEnvironment(parent.env(mod), TRUE)
        }


        mod <- makeModule(file)
        on.exit(.External2(.C_unregisterModule, package))
        mod$.packageName <- package
        if (grepl("/__init__\\.[Rr]$", file))
            .External2(.C_registerModule, dirname2(file), mod)


        save.enc <- options(encoding = "native.enc")
        res <- try(sys.source2(ofile, file, mod, keep.source, keep.parse.data))
        options(save.enc)
        if (inherits(res, "try-error"))
            stop(gettextf("unable to load R code in module %s", sQuote(file)), call. = FALSE)


        runHook(".onLoad", mod)
        sealModule(mod)
        runUserHook(file, mod)
        on.exit()
        mod
    }
}


loadModule <- eval(call("function", as.pairlist(alist(file = , keep.source = getOption("keep.source.mods"),
    keep.parse.data = getOption("keep.parse.data.mods"), n = 0L)), bquote(
{
    ofile <- file
    .(tmp.must.be.a.character.string("file"))
    .(tmp.normalize("file"))
    .loadModule(ofile, file, keep.source, keep.parse.data)
}
)))


unloadModule <- eval(call("function", as.pairlist(alist(mod = , n = 0L)), bquote(
{
    unload <- FALSE
    if (is.character(mod)) {
        .(tmp.must.be.a.character.string("mod"))
        if (any(mod == loadedModules()))
            unload <- TRUE
        else {
            tryCatch({
                .(tmp.normalize("mod"))
                unload <- TRUE
            }, error = identity)
        }
    }
    else if (is.environment(mod) && any(getModuleName(mod) == loadedModules()))
        unload <- TRUE
    if (unload) {
        runHook <- function(hookname, env) {
            if (!is.null(fun <- env[[hookname]])) {
                res <- tryCatch(fun(env), error = identity)
                if (inherits(res, "error")) {
                    stop(gettextf("%s failed in %s() for '%s', details:\n  call: %s\n  error: %s",
                        hookname, "unloadModule", getModuleName(env), deparse(conditionCall(res))[1L],
                        conditionMessage(res)), call. = FALSE)
                }
            }
        }
        runUserHook <- function(file, mod) {
            files <- if (grepl("/__init__\\.[Rr]$", file))
                c(file, dirname2(file))
            else file
            x <- names(.userHooksEnv)
            x <- x[startsWith(x, "UserHook::")]
            x <- x[endsWith(x, "::onUnload")]
            x <- substr(x, 11L, nchar(x) - 10L)
            x <- x[grepl("^(ftp|ftps|http|https)://", x) | .is.abs.path(x)]
            for (file in files) {
                xx <- x["." == .relpath(x, file, normalize = FALSE, normalize.path = FALSE)]
                for (hookName in .moduleEvent(xx, "onUnload")) {
                    hooks <- getHook(hookName)
                    for (fun in rev(hooks)) try(fun(mod))
                }
            }
        }
        mod <- asModule(mod, n = n + 1L)
        modname <- getModuleName(mod)
        users <- getModuleUsers(mod)
        if (length(users))
            stop(gettextf("module %s is imported by %s so cannot be unloaded",
                sQuote(modname), paste(sQuote(users), collapse = ", ")))
        runUserHook(.getModuleInfo(mod, "path"), mod)
        runHook(".onUnload", mod)
        .External2(.C_unregisterModule, modname)
    }
    invisible()
}
)))


.getModule <- function (file)
.External2(.C_getRegisteredModule, file)


getModule <- eval(call("function", as.pairlist(alist(file = , n = 0L)), bquote(
{
    ofile <- file
    .(tmp.must.be.a.character.string("file"))
    mod <- .External2(.C_getRegisteredModule, file)
    if (!is.null(mod))
        mod
    else {
        .(tmp.normalize("file"))
        mod <- .External2(.C_getRegisteredModule, file)
        if (!is.null(mod))
            mod
        else .loadModule(ofile, file)
    }
}
)))


rm(tmp.must.be.a.character.string)
rm(tmp.normalize)


asModule <- function (mod, n = 0L)
{
    if (is.character(mod))
        mod <- getModule(mod, n = n + 1L)
    else if (is.name(mod))
        mod <- getModule(as.character(mod), n = n + 1L)
    if (!isModule(mod))
        stop("not a module")
    else mod
}


S3method <- function (genname, class, method, envir = parent.frame())
{
    envir
    before.names <- names(envir)
    method
    after.names <- names(envir)
    if (is.function(method)) {
        new.names <- setdiff(after.names, before.names)
        if (i <- match(paste(genname, class, sep = "."), new.names, 0L))
            method <- new.names[[i]]
        else {
            if (length(new.names)) {
                for (sym in new.names) {
                    if (identical(method, get(sym, envir = envir))) {
                        method <- sym
                        break
                    }
                }
            }
            if (is.function(method)) {
                method <- substitute(method)
                if (is.symbol(method))
                    method <- as.character(method)
            }
        }
    }
    if (!is.character(method))
        stop("bad method", domain = "R-base")
    registerS3method(genname, class, method, envir)
    if (isModule(envir)) {
        regs <- rbind(.getModuleInfo(envir, "S3methods"),
            c(genname, class, method, NA_character_))
        setModuleInfo(envir, "S3methods", regs)
    }
}
