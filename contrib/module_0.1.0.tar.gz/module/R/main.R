setModuleInfo <- function (ns, which, val)
setNamespaceInfo(ns, which, val)


getModuleExports <- function (ns)
getNamespaceExports(ns)


getModuleImports <- function (ns)
getNamespaceImports(ns)


.getModuleInfo <- function (ns, which)
ns[[".__MODULE__."]][[which]]


getModuleInfo <- function (ns, which)
get(which, envir = ns[[".__MODULE__."]])


getModuleName <- function (ns)
ns[[".__MODULE__."]][["spec"]]["name"]


getModuleUsers <- function (ns)
getNamespaceUsers(ns)


getModuleVersion <- function (ns)
getNamespaceVersion(ns)


moduleExport <- function (ns, vars)
{
    if (environmentIsLocked(ns))
        stop("cannot add to exports of a sealed module")
    info <- ns[[".__MODULE__."]]
    info$exportPatterns <- c(info$exportPatterns, character(0))
    if (length(vars)) {
        addExports <- function(ns, new) {
            exports <- .getModuleInfo(ns, "exports")
            expnames <- names(new)
            objs <- names(exports)
            ex <- expnames %in% objs
            if (any(ex))
                warning(sprintf(ngettext(sum(ex), "previous export '%s' is being replaced",
                    "previous exports '%s' are being replaced", domain = "R"),
                    paste(sQuote(expnames[ex]), collapse = ", ")),
                    call. = FALSE, domain = NA)
            list2env(as.list(new), exports)
        }
        makeImportExportNames <- function(spec) {
            old <- as.character(spec)
            new <- names(spec)
            if (is.null(new))
                new <- old
            else {
                change <- !nzchar(new)
                new[change] <- old[change]
            }
            names(old) <- new
            old
        }
        new <- makeImportExportNames(unique(vars))
        undef <- new[!new %in% names(ns)]
        undef <- undef[!vapply(undef, exists, NA, envir = ns)]
        if (length(undef)) {
            print(undef)
            undef <- do.call("paste", as.list(c(undef, sep = ", ")))
            undef <- sub("^\\.__C__", "class ", undef)
            stop(gettextf("undefined exports: %s", undef, domain = "R"), domain = NA)
        }
        addExports(ns, new)
    }
}


moduleImport <- function (self, ..., from = NULL, except = character(0L))
namespaceImport(self = self, ..., from = from, except = except)


moduleImportClasses <- function (self, ns, vars, from = NULL)
namespaceImportClasses(self, ns, vars, from)


moduleImportFrom <- function (self, ns, vars, generics, packages, from = "non-package environment",
    except = character(0L))
namespaceImportFrom(self, ns, vars, generics, packages, from, except)


moduleImportMethods <- function (self, ns, vars, from = NULL)
namespaceImportMethods(self, ns, vars, from)


unloadModule <- function (ns)
unloadNamespace(ns)


makeModule <- function (name, version = NULL)
{
    impenv <- new.env(parent = .BaseNamespaceEnv, hash = TRUE)
    attr(impenv, "name") <- paste0("imports:", name)
    env <- new.env(parent = impenv, hash = TRUE)
    name <- as.character(as.symbol(name))
    version <- as.character(version)
    info <- new.env(hash = TRUE, parent = baseenv())
    env$.__MODULE__. <- info
    info$spec <- c(name = name, version = version)
    info$exports <- new.env(hash = TRUE, parent = baseenv())
    info$exportPatterns <- NULL
    dimpenv <- new.env(parent = baseenv(), hash = TRUE)
    attr(dimpenv, "name") <- paste0("lazydata:", name)
    info$lazydata <- dimpenv
    info$imports <- list(base = TRUE)
    info$path <- name
    info$dynlibs <- NULL
    info$S3methods <- matrix(NA_character_, 0L, 4L)
    env$.__S3MethodsTable__. <- new.env(hash = TRUE, parent = baseenv())
    env
}


.loadingModuleInfo <- NULL


asChar <- function (cc)
{
    r <- as.character(cc)
    if (any(r == ""))
        stop(gettextf("empty name in directive '%s' in 'NAMESPACE' file",
            as.character(e[[1L]])), domain = NA)
    r
}


evalToChar <- function (cc)
{
    vars <- all.vars(cc)
    names(vars) <- vars
    as.character(eval(eval(call("substitute", cc, as.list(vars))), .GlobalEnv))
}


export <- function (...)
{
    if (!is.null(.loadingModuleInfo)) {
        e <- sys.call()
        exp <- e[-1L]
        exp <- structure(asChar(exp), names = names(exp))
        exp


        stoplist <- c(".__NAMESPACE__.", ".__S3MethodsTable__.",
            ".packageName", ".First.lib", ".onLoad", ".onAttach",
            ".conflicts.OK", ".noGenerics")
        exp <- exp[!exp %in% stoplist]
        exp


        moduleExport(.loadingModuleInfo[[1L]], exp)
    }
}


exportPattern <- function (...)
{
    if (!is.null(.loadingModuleInfo)) {
        e <- sys.call()
        pat <- asChar(e[-1L])
        pat


        .loadingModuleInfo


        moduleExport(.loadingModuleInfo, exp)
    }
}


exportClassPattern <- function (...)
{
    e <- sys.call()
    pat <- asChar(e[-1L])
    pat
}


exportClass <- exportClasses <- function (...)
{
    e <- sys.call()
    asChar(e[-1L])
}


exportMethods <- function (...)
{
    e <- sys.call()
    asChar(e[-1L])
}


import <- function (...)
{
    e <- sys.call()
    except <- e$except
    e$except <- NULL
    pkgs <- as.list(asChar(e[-1L]))
    if (!is.null(except)) {
        pkgs <- lapply(pkgs, list, except = evalToChar(except))
    }
    for (i in pkgs) {
        if (is.character(i))
            moduleImport(ns, from = getModuleName(ns))
        if (!is.null(i$except))
            moduleImport(ns, from = getModuleName(ns), except = i$except)
        else moduleImportFrom(ns, i[[2L]], from = getModuleName(ns))
    }
}


importFrom <- function (...)
{
    e <- sys.call()
    imp <- e[-1L]
    ivars <- imp[-1L]
    inames <- names(ivars)
    imp <- list(asChar(imp[1L]), structure(asChar(ivars), names = inames))
    list(imp)
}


importClassFrom <- importClassesFrom <- function (...)
{
    e <- sys.call()
    imp <- asChar(e[-1L])
    pkg <- imp[[1L]]
    impClasses <- imp[-1L]
    imp <- list(asChar(pkg), asChar(impClasses))
    list(imp)
}


importMethodsFrom <- function (...)
{
    e <- sys.call()
    imp <- asChar(e[-1L])
    pkg <- imp[[1L]]
    impClasses <- imp[-1L]
    imp <- list(asChar(pkg), asChar(impClasses))
    list(imp)
}


useDynLib <- function (...)
{
    e <- sys.call()
    dyl <- as.character(e[2L])
    dynlibs <- structure(dyl, names = ifelse(!is.null(names(e)) && nzchar(names(e)[2L]), names(e)[2L], ""))
    if (length(e) > 2L) {
        symNames <- as.character(e[-c(1L, 2L)])
        names(symNames) <- names(e[-c(1L, 2L)])
        if (length(names(symNames)) == 0L)
            names(symNames) <- symNames
        else if (any(w <- names(symNames) == "")) {
            names(symNames)[w] <- symNames[w]
        }
        dup <- duplicated(names(symNames))
        if (any(dup))
            warning(gettextf("duplicate symbol names %s in useDynLib(\"%s\")",
                paste(sQuote(names(symNames)[dup]), collapse = ", "), dyl),
                domain = NA, call. = FALSE)
        symNames <- symNames[!dup]
        fixes <- c("", "")
        idx <- match(".fixes", names(symNames))
        if (!is.na(idx)) {
            if (nzchar(symNames[idx])) {
                e <- parse(text = symNames[idx], keep.source = FALSE, srcfile = NULL)[[1L]]
                if (is.call(e))
                    val <- eval(e, .GlobalEnv)
                else val <- as.character(e)
                if (length(val))
                    fixes[seq_along(val)] <- val
            }
            symNames <- symNames[-idx]
        }
        useRegistration <- FALSE
        idx <- match(".registration", names(symNames))
        if (!is.na(idx)) {
            useRegistration <- as.logical(symNames[idx])
            symNames <- symNames[-idx]
        }
        nativeRoutines[[dyl]] <<- if (dyl %in% names(nativeRoutines)) mergeNativeRoutineMaps(nativeRoutines[[dyl]],
                                                                                             useRegistration, symNames, fixes) else nativeRoutineMap(useRegistration,
                                                                                                                                                     symNames, fixes)
    }
}


S3method <- function (...)
{
    e <- sys.call()
    spec <- e[-1L]
    if (length(spec) != 2L && length(spec) != 3L)
        stop(gettextf("bad 'S3method' directive: %s", deparse(e)), call. = FALSE, domain = NA)
    S3methods <- matrix(NA_character_, 1L, 4L)
    if (is.call(gen <- spec[[1L]]) && identical(as.character(gen[[1L]]), "::")) {
        pkg <- as.character(gen[[2L]])[1L]
        gen <- as.character(gen[[3L]])[1L]
        S3methods[1L, c(seq_along(spec), 4L)] <- c(gen, asChar(spec[-1L]), pkg)
    }
    else S3methods[1L, seq_along(spec)] <- asChar(spec)
    S3methods
}


tmp <- as.list(quote({
    if (!is.character(file) || length(file) != 1L)
        stop(gettextf("'%s' must be a character string", "file", domain = "R"), domain = NA)
    if (grepl("^(ftp|ftps|http|https)://", file)) {
    }
    else {
        if (!this.path:::.is.abs.path(file))
            file <- this.path::ici(file)
        if (!file.exists(file))
            stop(gettextf("'%s' is not an existing file", "file", domain = "R"), domain = NA)
        file <- normalizePath(file, "/", TRUE)
    }
})[-1])


mynamespace <- environment()


loadModule <- function(file, keep.source = getOption("keep.source")) NULL
body(loadModule) <- bquote({
    ..(tmp)
    package <- as.character(as.symbol(file))
    loading <- .loadingModuleInfo[[2L]]
    if (match(package, loading, 0L))
        stop("cyclic module dependency detected when loading ", sQuote(package),
             ", already loading ", paste(sQuote(loading), collapse = ", "),
             domain = NA)
    # ns <- .External2(.C_getregisteredmodule, package)
    mod <- NULL
    if (!is.null(mod)) {
        mod
    }
    else {
        mod <- makeModule(package)
        mod$.packageName <- package


        old.loadingModuleInfo <- .loadingModuleInfo
        on.exit({
            (unlockBinding)(".loadingModuleInfo", mynamespace)
            assign(".loadingModuleInfo", old.loadingModuleInfo, envir = mynamespace, inherits = FALSE)
            lockBinding(".loadingModuleInfo", mynamespace)
        }, add = TRUE)
        (unlockBinding)(".loadingModuleInfo", mynamespace)
        assign(".loadingModuleInfo", list(mod, ModulesLoading = c(package, loading)),
            envir = mynamespace, inherits = FALSE)
        lockBinding(".loadingModuleInfo", mynamespace)


        sys.source(file, mod, keep.source = keep.source)
        if (environmentIsLocked(mod))
            stop(gettextf("module %s is already sealed in 'loadModule'",
                sQuote(getModuleName(mod))), call. = FALSE, domain = NA)
        lockEnvironment(mod, TRUE)
        lockEnvironment(parent.env(mod), TRUE)


        (unlockBinding)(".loadingModuleInfo", mynamespace)
        assign(".loadingModuleInfo", old.loadingModuleInfo, envir = mynamespace, inherits = FALSE)
        lockBinding(".loadingModuleInfo", mynamespace)


        on.exit()
        mod
    }
}, splice = TRUE)


getModule <- function(file) NULL
body(getModule) <- bquote({
    ..(tmp)
    ns <- .External2(.C_getregisteredmodule, file)
    if (!is.null(ns))
        ns
    else loadModule(file)
}, splice = TRUE)


rm(tmp)


isModule <- function (ns)
isNamespace(ns)


asModule <- function (ns, base.OK = TRUE)
{
    if (is.character(ns))
        ns <- getModule(ns)
    else if (is.name(ns))
        ns <- getModule(as.character(ns))
    if (!isModule(ns))
        stop("not a module", domain = "R-base")
    else if (!base.OK && isBaseNamespace(ns))
        stop("operation not allowed on base namespace")
    else ns
}
