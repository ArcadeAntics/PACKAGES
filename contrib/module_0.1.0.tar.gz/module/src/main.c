#include "moduledefn.h"


static SEXP checkModuleName(SEXP call, SEXP name)
{
    switch (TYPEOF(name)) {
    case SYMSXP:
        break;
    case STRSXP:
        if (LENGTH(name) >= 1L) {
            name = installTrChar(STRING_ELT(name, 0));
            break;
        }
    default:
        errorcall(call, "bad module name");
    }
    return name;
}


Rboolean isRegisteredModule(SEXP env)
{
    if (TYPEOF(env) == ENVSXP) {
        SEXP names = R_lsInternal3(ModuleRegistry, /* all */ TRUE, /* sorted */ FALSE);
        PROTECT(names);
        for (int i = 0, n = LENGTH(names); i < n; i++) {
            if (env == findVarInFrame(ModuleRegistry, installTrChar(STRING_ELT(names, i)))) {
                UNPROTECT(1);
                return TRUE;
            }
        }
        UNPROTECT(1);
        return FALSE;
    }
    else return FALSE;
}


Rboolean IsModuleEnv(SEXP rho)
{
    if (TYPEOF(rho) == ENVSXP) {
        SEXP info = findVarInFrame(rho, ModuleSymbol);
        if (info != R_UnboundValue && TYPEOF(info) == ENVSXP) {
            SEXP spec = findVarInFrame(info, specSymbol);
            if (spec != R_UnboundValue && TYPEOF(spec) == STRSXP && LENGTH(spec) > 0)
                return TRUE;
        }
    }
    return FALSE;
}


SEXP do_isRegisteredModule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);
    return ScalarLogical(isRegisteredModule(CAR(args)));
}


SEXP do_isModuleEnv(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);
    return IsModuleEnv(CAR(args)) ? R_TrueValue : R_FalseValue;
}


SEXP do_getRegisteredModule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    SEXP name = checkModuleName(call, coerceVector(CAR(args), SYMSXP));
    SEXP value = findVarInFrame(ModuleRegistry, name);
    if (value == R_UnboundValue)
        return R_NilValue;
    else
        return value;
}


SEXP do_registerModule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    SEXP name = checkModuleName(call, CAR(args));
    SEXP value = CADR(args);
    if (findVarInFrame(ModuleRegistry, name) != R_UnboundValue)
        errorcall(call, "module already registered");
    defineVar(name, value, ModuleRegistry);
    return R_NilValue;
}


SEXP do_unregisterModule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    SEXP name = checkModuleName(call, CAR(args));
    SEXP env = findVarInFrame(ModuleRegistry, name);
    if (env == R_UnboundValue)
        errorcall(call, "module not registered");
    R_removeVarFromFrame(name, ModuleRegistry);
    /* remove the same module with a different name */
    {
        SEXP names = R_lsInternal3(ModuleRegistry, /* all */ TRUE, /* sorted */ FALSE);
        PROTECT(names);
        for (int i = 0, n = LENGTH(names); i < n; i++) {
            name = installTrChar(STRING_ELT(names, i));
            if (env == findVarInFrame(ModuleRegistry, name))
                R_removeVarFromFrame(name, ModuleRegistry);
        }
        UNPROTECT(1);
    }
    return R_NilValue;
}


SEXP do_getModuleRegistry(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    return ModuleRegistry;
}


void _importIntoEnv(SEXP impenv, SEXP impnames, SEXP expenv, SEXP expnames)
{
    int nprotect = 0;


    SEXP impsym, expsym;
    SEXP val;


    if (TYPEOF(impenv) != ENVSXP) error(_("bad import environment argument"));
    if (TYPEOF(expenv) != ENVSXP) error(_("bad export environment argument"));
    if (expnames == R_NilValue) { PROTECT(expnames = R_lsInternal3(expenv, /* all */ FALSE, /* sorted */ FALSE)); nprotect++; }
    if (impnames == R_NilValue) impnames = expnames;
    if (TYPEOF(impnames) != STRSXP || TYPEOF(expnames) != STRSXP)
        error(_("invalid '%s' argument"), "names");
    if (LENGTH(impnames) != LENGTH(expnames))
        error(_("length of import and export names must match"));


    for (int i = 0, n = LENGTH(impnames); i < n; i++) {
        impsym = installTrChar(STRING_ELT(impnames, i));
        expsym = installTrChar(STRING_ELT(expnames, i));


        if (!R_existsVarInFrame(expenv, expsym)) {
            error(_("exported symbol '%s' has no value"), CHAR(PRINTNAME(expsym)));
        }
        else if (R_BindingIsActive(expsym, expenv)) {
            val = R_ActiveBindingFunction(expsym, expenv);
            R_MakeActiveBinding(impsym, val, impenv);
        }
        else if ((val = findVarInFrame(expenv, expsym)) == R_UnboundValue) {
            error(_("exported symbol '%s' has no value"), CHAR(PRINTNAME(expsym)));
        }
        else {
            defineVar(impsym, val, impenv);
        }
    }


    if (nprotect) UNPROTECT(nprotect);
}


void importIntoEnv4(SEXP impenv, SEXP impnames, SEXP expenv, SEXP expnames)
{
    _importIntoEnv(impenv, impnames, expenv, expnames);
}


void importIntoEnv3(SEXP impenv, SEXP expenv, SEXP expnames)
{
    importIntoEnv4(impenv, R_NilValue, expenv, expnames);
}


void importIntoEnv2(SEXP impenv, SEXP expenv)
{
    importIntoEnv3(impenv, expenv, R_NilValue);
}


SEXP do_importIntoEnv(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    switch (length(args)) {
    case 2:
        importIntoEnv2(CAR(args), CADR(args));
        break;
    case 3:
        importIntoEnv3(CAR(args), CADR(args), CADDR(args));
        break;
    case 4:
        importIntoEnv4(CAR(args), CADR(args), CADDR(args), CADDDR(args));
        break;
    default:
        errorcall(call, length(args) == 1 ? "%d argument passed to .External(%s) which requires %s" :
                                            "%d arguments passed to .External(%s) which requires %s",
            length(args), ".C_importIntoEnv", "2, 3, or 4");
    }


    return R_NilValue;
}


SEXP do_checkSameBindings(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    SEXP impenv, impnames, impsym,
         expenv, expnames, expsym;


    switch (length(args)) {
    case 2:
        impenv   = CAR(args); args = CDR(args);
        impnames = R_NilValue;
        expenv   = CAR(args); args = CDR(args);
        expnames = R_NilValue;
        break;
    case 3:
        impenv   = CAR(args); args = CDR(args);
        impnames = R_NilValue;
        expenv   = CAR(args); args = CDR(args);
        expnames = CAR(args); args = CDR(args);
        break;
    case 4:
        impenv   = CAR(args); args = CDR(args);
        impnames = CAR(args); args = CDR(args);
        expenv   = CAR(args); args = CDR(args);
        expnames = CAR(args); args = CDR(args);
        break;
    default:
        errorcall(call, length(args) == 1 ? "%d argument passed to .External(%s) which requires %s" :
                                            "%d arguments passed to .External(%s) which requires %s",
            length(args), ".C_checkSameBindings", "2, 3, or 4");
    }


    int nprotect = 0;


    if (TYPEOF(impenv) != ENVSXP) error(_("bad import environment argument"));
    if (TYPEOF(expenv) != ENVSXP) error(_("bad export environment argument"));
    if (expnames == R_NilValue) { PROTECT(expnames = R_lsInternal3(expenv, /* all */ FALSE, /* sorted */ FALSE)); nprotect++; }
    if (impnames == R_NilValue) impnames = expnames;
    if (TYPEOF(impnames) != STRSXP || TYPEOF(expnames) != STRSXP)
        error(_("invalid '%s' argument"), "names");
    if (LENGTH(impnames) != LENGTH(expnames))
        error(_("length of import and export names must match"));


    for (int i = 0, n = LENGTH(impnames); i < n; i++) {
        impsym = installTrChar(STRING_ELT(impnames, i));
        expsym = installTrChar(STRING_ELT(expnames, i));


        if (!R_existsVarInFrame(impenv, impsym));
        else if (!R_existsVarInFrame(expenv, expsym)) {
            error(_("exported symbol '%s' has no value"), CHAR(PRINTNAME(expsym)));
        }
        else if (R_BindingIsActive(expsym, expenv)) {
            if (R_BindingIsActive(impsym, impenv) &&
                R_ActiveBindingFunction(expsym, expenv) == R_ActiveBindingFunction(impsym, impenv));
            else
                warning(_("replacing previous import by %s when loading %s"),
                    CHAR(PRINTNAME(expsym)), "non-package environment");
        }
        else if (!R_BindingIsActive(impsym, impenv) &&
                 findVarInFrame(expenv, expsym) == findVarInFrame(impenv, impsym));
        else
            warning(_("replacing previous import by %s when loading %s"),
                CHAR(PRINTNAME(expsym)), "non-package environment");
    }


    if (nprotect) UNPROTECT(nprotect);
    return R_NilValue;
}
