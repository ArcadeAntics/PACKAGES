#include "moduledefn.h"


static SEXP checkModuleName(SEXP call, SEXP name)
{
    switch (TYPEOF(name)) {
    case SYMSXP:
        break;
    case STRSXP:
        if (LENGTH(name) >= 1L) {
            name = installTrChar(STRING_ELT(name, 0));
            break;
        }
    default:
        errorcall(call, "bad module name");
    }
    return name;
}


Rboolean isRegisteredModule(SEXP env)
{
    if (TYPEOF(env) == ENVSXP) {
        SEXP names = R_lsInternal3(ModuleRegistry, /* all */ TRUE, /* sorted */ FALSE);
        PROTECT(names);
        for (int i = 0, n = LENGTH(names); i < n; i++) {
            if (env == findVarInFrame(ModuleRegistry, installTrChar(STRING_ELT(names, i)))) {
                UNPROTECT(1);
                return TRUE;
            }
        }
        UNPROTECT(1);
        return FALSE;
    }
    else return FALSE;
}


SEXP do_isRegisteredModule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);
    return ScalarLogical(isRegisteredModule(CAR(args)));
}


SEXP do_getRegisteredModule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);
    SEXP name = checkModuleName(call, coerceVector(CAR(args), SYMSXP));
    SEXP value = findVarInFrame(ModuleRegistry, name);
    if (value == R_UnboundValue)
        return R_NilValue;
    else
        return value;
}


SEXP do_registerModule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);
    SEXP name = checkModuleName(call, CAR(args));
    SEXP value = CADR(args);
    if (findVarInFrame(ModuleRegistry, name) != R_UnboundValue)
        errorcall(call, "module already registered");
    defineVar(name, value, ModuleRegistry);
    return R_NilValue;
}


SEXP do_unregisterModule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);
    SEXP name = checkModuleName(call, CAR(args));
    SEXP env = findVarInFrame(ModuleRegistry, name);
    if (env == R_UnboundValue)
        errorcall(call, "module not registered");
    R_removeVarFromFrame(name, ModuleRegistry);
    /* remove the same module with a different name */
    {
        SEXP names = R_lsInternal3(ModuleRegistry, /* all */ TRUE, /* sorted */ FALSE);
        PROTECT(names);
        for (int i = 0, n = LENGTH(names); i < n; i++) {
            name = installTrChar(STRING_ELT(names, i));
            if (env == findVarInFrame(ModuleRegistry, name))
                R_removeVarFromFrame(name, ModuleRegistry);
        }
    }
    return R_NilValue;
}
