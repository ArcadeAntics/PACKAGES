#include <R.h>
#include <Rinternals.h>


static SEXP checkModuleName(SEXP call, SEXP name)
{
    switch (TYPEOF(name)) {
    case SYMSXP:
        break;
    case STRSXP:
        if (LENGTH(name) >= 1L) {
            name = installTrChar(STRING_ELT(name, 0));
            break;
        }
    default:
        errorcall(call, "bad module name");
    }
    return name;
}


SEXP do_getregisteredmodule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);
    SEXP name = checkModuleName(call, coerceVector(CAR(args), SYMSXP));
    SEXP value = findVarInFrame(R_NamespaceRegistry, name);
    if (value == R_UnboundValue)
        return R_NilValue;
    else
        return value;
}


SEXP do_registermodule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);
    SEXP name = checkModuleName(call, CAR(args));
    SEXP value = CADR(args);
    if (findVarInFrame(R_NamespaceRegistry, name) != R_UnboundValue)
        errorcall(call, "module already registered");
    defineVar(name, value, R_NamespaceRegistry);
    return R_NilValue;
}


SEXP do_unregistermodule(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);
    SEXP name = checkModuleName(call, CAR(args));
    if (findVarInFrame(R_NamespaceRegistry, name) == R_UnboundValue)
        errorcall(call, "module not registered");
    R_removeVarFromFrame(name, R_NamespaceRegistry);
    return R_NilValue;
}
