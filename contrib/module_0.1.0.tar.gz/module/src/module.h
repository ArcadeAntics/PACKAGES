#ifndef R_MODULE_H
#define R_MODULE_H


#include <Rinternals.h>


/* main.c */


extern SEXP do_isRegisteredModule (SEXP call, SEXP op, SEXP args, SEXP rho);
extern SEXP do_isModuleEnv        (SEXP call, SEXP op, SEXP args, SEXP rho);
extern SEXP do_getRegisteredModule(SEXP call, SEXP op, SEXP args, SEXP rho);
extern SEXP do_registerModule     (SEXP call, SEXP op, SEXP args, SEXP rho);
extern SEXP do_unregisterModule   (SEXP call, SEXP op, SEXP args, SEXP rho);
extern SEXP do_getModuleRegistry  (SEXP call, SEXP op, SEXP args, SEXP rho);
extern SEXP do_importIntoEnv      (SEXP call, SEXP op, SEXP args, SEXP rho);


/* ns-hooks.c */


extern SEXP do_onLoad  (SEXP call, SEXP op, SEXP args, SEXP rho);
extern SEXP do_onUnload(SEXP call, SEXP op, SEXP args, SEXP rho);


#endif  /* #ifndef R_MODULE_H */
