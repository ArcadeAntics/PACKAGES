#ifndef R_MODULE_H
#define R_MODULE_H


#include <Rinternals.h>


/* main.c */


extern SEXP do_getregisteredmodule(SEXP call, SEXP op, SEXP args, SEXP rho);
extern SEXP do_registermodule     (SEXP call, SEXP op, SEXP args, SEXP rho);
extern SEXP do_unregistermodule   (SEXP call, SEXP op, SEXP args, SEXP rho);


#endif  /* #ifndef R_MODULE_H */
