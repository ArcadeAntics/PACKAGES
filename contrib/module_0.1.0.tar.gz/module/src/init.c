#include <R_ext/Rdynload.h>
#include <R_ext/Visibility.h>
#include "module.h"


static const R_ExternalMethodDef externalRoutines[] = {


    /* main.c */


    {"getregisteredmodule", (DL_FUNC) &do_getregisteredmodule, 1},
    {"registermodule"     , (DL_FUNC) &do_registermodule     , 2},
    {"unregistermodule"   , (DL_FUNC) &do_unregistermodule   , 1},


    {NULL, NULL, 0}
};


void attribute_visible R_init_module(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, NULL, NULL, externalRoutines);
    R_useDynamicSymbols(dll, FALSE);
    R_forceSymbols(dll, TRUE);
}
