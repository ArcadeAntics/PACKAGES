#include <R_ext/Rdynload.h>
#include <R_ext/Visibility.h>
#include "module.h"


static const R_ExternalMethodDef externalRoutines[] = {


    /* main.c */


    {"isRegisteredModule" , (DL_FUNC) &do_isRegisteredModule ,  1},
    {"isModuleEnv"        , (DL_FUNC) &do_isModuleEnv        ,  1},
    {"getRegisteredModule", (DL_FUNC) &do_getRegisteredModule,  1},
    {"registerModule"     , (DL_FUNC) &do_registerModule     ,  2},
    {"unregisterModule"   , (DL_FUNC) &do_unregisterModule   ,  1},
    {"getModuleRegistry"  , (DL_FUNC) &do_getModuleRegistry  ,  0},
    {"importIntoEnv"      , (DL_FUNC) &do_importIntoEnv      , -1},
    {"checkSameBindings"  , (DL_FUNC) &do_checkSameBindings  , -1},


    /* ns-hooks.c */


    {"onLoad"  , (DL_FUNC) &do_onLoad  , 2},
    {"onUnload", (DL_FUNC) &do_onUnload, 1},


    {NULL, NULL, 0}
};


void attribute_visible R_init_module(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, NULL, NULL, externalRoutines);
    R_useDynamicSymbols(dll, FALSE);
    R_forceSymbols(dll, TRUE);
}
