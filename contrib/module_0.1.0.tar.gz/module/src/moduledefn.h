#ifndef R_MODULEDEFN_H
#define R_MODULEDEFN_H


#include <R.h>
#include <Rinternals.h>


#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String) dgettext ("R", String)
#else
#define _(String) (String)
#endif


LibExtern SEXP R_TrueValue;
LibExtern SEXP R_FalseValue;
LibExtern SEXP R_LogicalNAValue;


extern const char *_packageName;
extern SEXP mynamespace;
extern SEXP ModuleRegistry;


extern SEXP ModuleSymbol;
extern SEXP specSymbol;


#endif
