#ifndef R_MODULEDEFN_H
#define R_MODULEDEFN_H


#include <R.h>
#include <Rinternals.h>


const char *_packageName;
SEXP ModuleRegistry;


extern SEXP R_NewHashedEnv(SEXP enclos, int size);


#endif
