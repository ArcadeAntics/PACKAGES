#ifndef R_MODULEDEFN_H
#define R_MODULEDEFN_H


#include <R.h>
#include <Rinternals.h>


#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String) dgettext ("R", String)
#else
#define _(String) (String)
#endif


const char *_packageName;
SEXP ModuleRegistry;


extern SEXP R_NewHashedEnv(SEXP enclos, int size);
extern SEXP R_TrueValue;
extern SEXP R_FalseValue;
extern SEXP R_LogicalNAValue;


extern SEXP ModuleSymbol;
extern SEXP specSymbol;


#endif
