#include "moduledefn.h"


SEXP do_onLoad(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    _packageName = CHAR(STRING_ELT(CADR(args), 0));


    ModuleRegistry = R_NewHashedEnv(R_NilValue, 0);
    R_PreserveObject(ModuleRegistry);


    return R_NilValue;
}


SEXP do_onUnload(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    R_ReleaseObject(ModuleRegistry);


    {
        SEXP expr;
        PROTECT_INDEX indx;
        PROTECT_WITH_INDEX(expr = CONS(CAR(args), R_NilValue), &indx);
        REPROTECT(expr = CONS(mkString(_packageName), expr), indx);
        REPROTECT(expr = LCONS(install("library.dynam.unload"), expr), indx);
        REPROTECT(expr = CONS(expr, R_NilValue), indx);
        REPROTECT(expr = LCONS(install("on.exit"), expr), indx);
        eval(expr, rho);
        UNPROTECT(1);
    }


    return R_NilValue;
}
