#include "moduledefn.h"


SEXP ModuleSymbol = NULL;
SEXP specSymbol   = NULL;


SEXP do_onLoad(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    _packageName = CHAR(STRING_ELT(CADR(args), 0));


    ModuleSymbol = install(".__MODULE__.");
    specSymbol   = install("spec");


    {
        char *p;
        SEXP expr;
        PROTECT_INDEX indx;
        PROTECT_WITH_INDEX(expr = R_NilValue, &indx);


        p = getenv("R_KEEP_MOD_PARSE_DATA");
        REPROTECT(expr = CONS((p && (strcmp(p, "no") == 0)) ? R_FalseValue : R_TrueValue, expr), indx);
        SET_TAG(expr, install("keep.parse.data.mods"));


        p = getenv("R_KEEP_MOD_SOURCE");
        REPROTECT(expr = CONS((p && (strcmp(p, "no") == 0)) ? R_FalseValue : R_TrueValue, expr), indx);
        SET_TAG(expr, install("keep.source.mods"));


        REPROTECT(expr = LCONS(install("options"), expr), indx);
        eval(expr, R_BaseEnv);
        UNPROTECT(1);
    }


    ModuleRegistry = R_NewHashedEnv(R_NilValue, 0);
    R_PreserveObject(ModuleRegistry);


    return R_NilValue;
}


SEXP do_onUnload(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    R_ReleaseObject(ModuleRegistry);


    {
        SEXP expr;
        PROTECT_INDEX indx;
        PROTECT_WITH_INDEX(expr = CONS(CAR(args), R_NilValue), &indx);
        REPROTECT(expr = CONS(mkString(_packageName), expr), indx);
        REPROTECT(expr = LCONS(install("library.dynam.unload"), expr), indx);
        REPROTECT(expr = CONS(expr, R_NilValue), indx);
        REPROTECT(expr = LCONS(install("on.exit"), expr), indx);
        eval(expr, rho);
        UNPROTECT(1);
    }


    return R_NilValue;
}
