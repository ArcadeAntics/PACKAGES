#include "moduledefn.h"
#include <Rversion.h>


const char *_packageName = NULL;
SEXP mynamespace;
SEXP ModuleRegistry;


SEXP ModuleSymbol = NULL;
SEXP specSymbol   = NULL;


extern void importIntoEnv4(SEXP, SEXP, SEXP, SEXP);


SEXP do_onLoad(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    _packageName = CHAR(STRING_ELT(CADR(args), 0));
    mynamespace = findVarInFrame(R_NamespaceRegistry, install(_packageName));


    {
        SEXP impenv = ENCLOS(mynamespace);
        SEXP expenv = findVarInFrame(R_NamespaceRegistry, install("this.path"));
        const char *names[] = {
            ".is.abs.path",
            ".normalizeURL.1",
            ".relpath",
            NULL
        };
        int n = 0; while (names[n]) n++;
        SEXP expnames = allocVector(STRSXP, n);
        PROTECT(expnames);
        for (int i = 0; i < n; i++)
            SET_STRING_ELT(expnames, i, mkChar(names[i]));
        importIntoEnv4(impenv, expnames, expenv, expnames);
        UNPROTECT(1);
    }


    ModuleSymbol = install(".__MODULE__.");
    specSymbol   = install("spec");


    {
        char *p;
        SEXP expr;
        PROTECT_INDEX indx;
        PROTECT_WITH_INDEX(expr = R_NilValue, &indx);


        p = getenv("R_KEEP_MOD_PARSE_DATA");
        REPROTECT(expr = CONS((p && (strcmp(p, "no") == 0)) ? R_FalseValue : R_TrueValue, expr), indx);
        SET_TAG(expr, install("keep.parse.data.mods"));


        p = getenv("R_KEEP_MOD_SOURCE");
        REPROTECT(expr = CONS((p && (strcmp(p, "no") == 0)) ? R_FalseValue : R_TrueValue, expr), indx);
        SET_TAG(expr, install("keep.source.mods"));


        REPROTECT(expr = LCONS(install("options"), expr), indx);
        eval(expr, R_BaseEnv);
        UNPROTECT(1);
    }


    ModuleRegistry = R_NewEnv(/* enclos */ R_NilValue, /* hash */ TRUE, /* size */ 0);
    R_PreserveObject(ModuleRegistry);


    return R_NilValue;
}


SEXP do_onUnload(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    args = CDR(args);


    R_ReleaseObject(ModuleRegistry);


    {
        SEXP expr;
        PROTECT_INDEX indx;
        PROTECT_WITH_INDEX(expr = CONS(CAR(args), R_NilValue), &indx);
        REPROTECT(expr = CONS(mkString(_packageName), expr), indx);
        REPROTECT(expr = LCONS(install("library.dynam.unload"), expr), indx);
        REPROTECT(expr = CONS(expr, R_NilValue), indx);
        REPROTECT(expr = LCONS(install("on.exit"), expr), indx);
        eval(expr, rho);
        UNPROTECT(1);
    }


    return R_NilValue;
}
