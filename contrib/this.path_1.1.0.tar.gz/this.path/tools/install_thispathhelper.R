install_thispathhelper <- function ()
{
    if (getRversion() >= "3.3.0") {
        lib <- Sys.getenv("R_LIBRARY_DIR", NA_character_)
        lib.loc <- if (is.na(lib)) .libPaths() else c(lib, .libPaths())
        lib <- lib.loc[1L]
        if (requireNamespace("this.path.helper", lib.loc, quietly = TRUE)) {
            invisible()
        } else {
            FILE <- tempfile(fileext = ".txt")
            on.exit(unlink(FILE, force = TRUE, expand = TRUE))
            conn <- file(FILE, "w")
            on.exit(close(conn), add = TRUE, after = FALSE)
            sink(conn)
            on.exit(sink(), add = TRUE, after = FALSE)
            sink(conn, type = "message")
            on.exit(sink(type = "message"), add = TRUE, after = FALSE)
            destdir <- tempfile("downloaded_packages")
            on.exit(unlink(destdir, force = TRUE, recursive = TRUE, expand = FALSE), add = TRUE, after = FALSE)
            dir.create(destdir, showWarnings = FALSE, recursive = TRUE)
            repos <- "https://raw.githubusercontent.com/ArcadeAntics/PACKAGES"
            fun <- function(type) {
                suppressWarnings(utils::download.packages("this.path.helper",
                    destdir = destdir, repos = repos, type = type))
            }
            pkgs <- character()
            print(getOption("pkgType"))
            if (.Platform$pkgType != "source") {
                pkgType <- getOption("pkgType")
                if (!is.null(pkgType) && pkgType != "source") {
                    pkgs <- fun(.Platform$pkgType)
                }
            }
            if (!length(pkgs)) {
                pkgs <- fun("source")
            }
            # if the package cannot be found online, install from local tarball
            pkgs <- if (length(pkgs)) pkgs[[1L, 2L]] else "./tools/this.path.helper_0.1.0.tar.gz"
            utils::install.packages(pkgs, lib, repos = NULL, verbose = FALSE, quiet = TRUE)
        }
    }
}


install_thispathhelper()
# cat('\n> requireNamespace("this.path.helper")\n'); print(requireNamespace("this.path.helper", if (is.na(lib <- Sys.getenv("R_LIBRARY_DIR", NA_character_))) .libPaths() else c(lib, .libPaths()), quietly = TRUE))
