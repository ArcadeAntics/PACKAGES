install_thispathhelper <- function ()
{
    if (requireNamespace("this.path.helper", quietly = TRUE))
        invisible()
    else {
        FILE <- tempfile()
        on.exit(unlink(FILE, force = TRUE, expand = TRUE))
        con <- file(FILE, "w")
        on.exit(close(con), add = TRUE, after = FALSE)
        sink(con)
        on.exit(sink(), add = TRUE, after = FALSE)
        sink(con, type = "message")
        on.exit(sink(type = "message"), add = TRUE, after = FALSE)
        suppressWarnings(utils::install.packages("this.path.helper", repos =
            "https://raw.githubusercontent.com/ArcadeAntics/PACKAGES",
            verbose = FALSE, INSTALL_opts = "--no-staged-install", quiet = TRUE))
    }
}


install_thispathhelper()
cat('\n> requireNamespace("this.path.helper", quietly = TRUE)\n'); print(requireNamespace("this.path.helper", quietly = TRUE))
