install_thispathhelper <- function ()
{
    if (requireNamespace("this.path.helper", quietly = TRUE))
        invisible()
    else {
        utils::install.packages("this.path.helper", repos =
            "https://raw.githubusercontent.com/ArcadeAntics/PACKAGES")
    }
}


install_thispathhelper()
