wrap.source <- function (expr, file, character.only = FALSE, file.only = FALSE)
{
    done <- FALSE
    if (missing(expr))
        expr
    if (missing(file))
        .External2(C_wrapsource, character.only, file.only)
    else .External2(C_wrapsource, file, character.only, file.only)
}


within.source <- function (file, character.only = FALSE, file.only = FALSE)
.External2(C_withinsource, file, character.only, file.only, parent.frame())
