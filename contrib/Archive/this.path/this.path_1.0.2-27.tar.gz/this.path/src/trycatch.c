#include <R.h>
#include <Rinternals.h>





#define set_R_Visible(X) (eval( (X) ? R_NilValue : lang1(install("invisible")) , R_BaseEnv))





SEXP do_assigninplace(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    SEXP x = CADR(args);
    SEXP value = CADDR(args);
    switch (TYPEOF(x)) {
    case LGLSXP:
        LOGICAL(x)[0] = asLogical(value);
        break;
    case INTSXP:
        INTEGER(x)[0] = asInteger(value);
        break;
    case REALSXP:
        REAL(x)[0] = asReal(value);
        break;
    case CPLXSXP:
        COMPLEX(x)[0] = asComplex(value);
        break;
    case STRSXP:
        SET_STRING_ELT(x, 0, asChar(value));
        break;
    default:
        error("unimplemented type '%s' in '%s'", type2char(TYPEOF(x)), "assign.in.place");
        break;
    }
    return x;
}


SEXP do_trycatch(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    int nprotect = 0;


    SEXP finally = findVarInFrame(rho, install("finally"));
    if (finally == R_UnboundValue)
        error("unable to find 'finally'; should never happen, please report!");


    SEXP expr, value;


    if (finally != R_MissingArg) {
        expr = lang2(install("on.exit"), install("finally"));
        PROTECT(expr);
        eval(expr, rho);
        UNPROTECT(1);
    }


    SEXP else_ = findVarInFrame(rho, install("else."));
    if (else_ == R_UnboundValue)
        error("unable to find 'else.'; should never happen, please report!");


    if (else_ == R_MissingArg) {
        expr = lang3(install("tryCatch"), install("expr"), install("..."));
        PROTECT(expr); nprotect++;
        SET_TAG(CDR(expr), install("expr"));
        value = eval(expr, rho);
        UNPROTECT(nprotect);
        return value;
    }


    SEXP dots = findVarInFrame(rho, install("..."));
    if (dots == R_UnboundValue)
        error("unable to find the ... list; should never happen, please report!");


    int dots_length = ((TYPEOF(dots) == DOTSXP) ? length(dots) : 0);
    if (!dots_length)
        error("'tryCatch' with 'else.' but no condition handlers makes no sense");


    SEXP do_else = allocVector(LGLSXP, 1);
    PROTECT(do_else); nprotect++;
    LOGICAL(do_else)[0] = FALSE;


    expr = lang3(
        install("tryCatch"),
        lang3(
            R_BraceSymbol,
            install("expr"),
            lang3(
                install("assign.in.place"),
                do_else,
                ScalarLogical(TRUE)
            )
        ),
        install("...")
    );
    PROTECT(expr); nprotect++;
    SET_TAG(CDR(expr), install("expr"));
    expr = lang2(install("withVisible"), expr);
    PROTECT(expr); nprotect++;
    value = eval(expr, rho);
    PROTECT(value); nprotect++;


    if (LOGICAL_ELT(do_else, 0)) {
        value = eval(else_, rho);
        UNPROTECT(nprotect);
        return value;
    }


    set_R_Visible(LOGICAL_ELT(VECTOR_ELT(value, 1), 0));
    return VECTOR_ELT(value, 0);
}
