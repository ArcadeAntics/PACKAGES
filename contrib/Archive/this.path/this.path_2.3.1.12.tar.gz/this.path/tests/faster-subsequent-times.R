local({
    FILE <- tempfile(fileext = ".R")
    on.exit(unlink(FILE), add = TRUE)
    this.path:::.writeCode(file = FILE, {
        if (requireNamespace("microbenchmark")) {
            print(this.path:::.faster_subsequent_times_test())
        } else cat("\n'package:microbenchmark' is not available :(\n")
    })
    cat("\n")
    this.path:::.Rscript(c("--default-packages=NULL", "--vanilla", FILE))


    cat("\n> source(FILE, chdir = FALSE)\n")
    source(FILE, chdir = FALSE)


    cat("\n> source(FILE, chdir = TRUE)\n")
    source(FILE, chdir = TRUE)
})
