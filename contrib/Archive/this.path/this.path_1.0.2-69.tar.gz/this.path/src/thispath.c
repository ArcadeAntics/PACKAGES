#include <R.h>
#include <Rinternals.h>





#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String) dgettext ("R", String)
#else
#define _(String) (String)
#endif





#define set_R_Visible(v) (eval((v) ? R_NilValue : lang1(install("invisible")), R_BaseEnv))
#define streql(str1, str2) (strcmp((str1), (str2)) == 0)


extern SEXP findFun3(SEXP symbol, SEXP rho, SEXP call);
extern int pmatch(SEXP, SEXP, int);


extern void SET_PRCODE (SEXP x, SEXP v);
extern void SET_PRENV  (SEXP x, SEXP v);
extern void SET_PRSEEN (SEXP x, int  v);
extern void SET_PRVALUE(SEXP x, SEXP v);


extern int IS_ASCII(SEXP x);
extern const char *trCharUTF8(SEXP x);


extern void (ENSURE_NAMEDMAX)(SEXP x);


extern SEXP R_getNSValue(SEXP call, SEXP ns, SEXP name, int exported);


static R_INLINE int asFlag(SEXP x, const char *name)
{
    int val = asLogical(x);
    if (val == NA_LOGICAL)
	    error(_("invalid '%s' value"), name);
    return val;
}


int in_rstudio = -1;


SEXP do_thispath(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    int nprotect = 0;


    int testthat_loaded, knitr_loaded;


    SEXP tools_rstudio;
    SEXP debugSource;
    SEXP source_file;
    SEXP knit;


    args = CDR(args);


    int verbose  = asFlag(CAR(args), "verbose");
    int original = asFlag(CADR(args), "original");
    int for_msg  = asFlag(CADDR(args), "for.msg");
    int N        = asInteger(CADDDR(args));
    int get_frame_number = asFlag(CAD4R(args), "get.frame.number");


    if (in_rstudio == -1) {
        in_rstudio = asLogical(eval(install("gui.rstudio"), rho));
    }
    if (in_rstudio) {
        tools_rstudio = eval(lang2(
            install("as.environment"),
            mkString("tools:rstudio")
        ), R_BaseEnv);
        PROTECT(tools_rstudio); nprotect++;
        debugSource = findVarInFrame(tools_rstudio, install("debugSource"));
        if (debugSource == R_UnboundValue)
            error(_("object '%s' not found"), "debugSource");
        if (TYPEOF(debugSource) == PROMSXP) {
            if (PRVALUE(debugSource) == R_UnboundValue)
                debugSource = eval(debugSource, rho);
            else
                debugSource = PRVALUE(debugSource);
        }
        if (TYPEOF(debugSource) != CLOSXP)
            error(_("object '%s' of mode '%s' was not found"), "debugSource", "function");
    }
    else debugSource = R_NilValue;


    testthat_loaded = (findVarInFrame(R_NamespaceRegistry, install("testthat")) != R_UnboundValue);
    if (testthat_loaded)
        source_file = R_getNSValue(R_NilValue, install("testthat"), install("source_file"), TRUE);
    else
        source_file = R_NilValue;


    knitr_loaded = (findVarInFrame(R_NamespaceRegistry, install("knitr")) != R_UnboundValue);
    if (knitr_loaded)
        knit = R_getNSValue(R_NilValue, install("knitr"), install("knit"), TRUE);
    else
        knit = R_NilValue;


    // eval(lang2(install("print"), debugSource), rho);
    // eval(lang2(install("print"), source_file), rho);
    // eval(lang2(install("print"), knit), rho);


    UNPROTECT(nprotect);
    return R_NilValue;
}
