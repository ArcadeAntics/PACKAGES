#include <R.h>
#include <Rinternals.h>





#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String) dgettext ("R", String)
#else
#define _(String) (String)
#endif





#define set_R_Visible(v) (eval((v) ? R_NilValue : lang1(install("invisible")), R_BaseEnv))
#define streql(str1, str2) (strcmp((str1), (str2)) == 0)


extern SEXP findFun3(SEXP symbol, SEXP rho, SEXP call);
extern int pmatch(SEXP, SEXP, int);


extern void SET_PRCODE (SEXP x, SEXP v);
extern void SET_PRENV  (SEXP x, SEXP v);
extern void SET_PRSEEN (SEXP x, int  v);
extern void SET_PRVALUE(SEXP x, SEXP v);


extern int IS_ASCII(SEXP x);
extern const char *trCharUTF8(SEXP x);


extern void (ENSURE_NAMEDMAX)(SEXP x);


extern SEXP R_getNSValue(SEXP call, SEXP ns, SEXP name, int exported);





static R_INLINE int asFlag(SEXP x, const char *name)
{
    int val = asLogical(x);
    if (val == NA_LOGICAL)
        error(_("invalid '%s' value"), name);
    return val;
}


static SEXP getVarValInFrame(SEXP rho, SEXP sym, int unbound_ok)
{
    SEXP val = findVarInFrame(rho, sym);
    if (!unbound_ok && val == R_UnboundValue)
        error(_("object '%s' not found"), CHAR(PRINTNAME(sym)));
    if (TYPEOF(val) == PROMSXP) {
        if (PRVALUE(val) == R_UnboundValue)
            return eval(val, R_EmptyEnv);
        else
            return PRVALUE(val);
    }
    else return val;
}


static SEXP matchEnvir(const char *what)
{
    SEXP name;
    for (SEXP t = ENCLOS(R_GlobalEnv); t != R_EmptyEnv ; t = ENCLOS(t)) {
        name = getAttrib(t, R_NameSymbol);
        if (isString(name) &&
            length(name) > 0 &&
            !strcmp(translateChar(STRING_ELT(name, 0)), what))
        {
            return t;
        }
    }
    errorcall(lang2(install("as.environment"), mkString(what)),
        _("no item called \"%s\" on the search list"), what);
    return R_NilValue;
}


SEXP errorCondition(const char *msg, SEXP call, const char **cls, int n)
{
    SEXP cond = PROTECT(allocVector(VECSXP, 2));
    SET_VECTOR_ELT(cond, 0, mkString(msg));
    SET_VECTOR_ELT(cond, 1, call);


    SEXP names = allocVector(STRSXP, 2);
    setAttrib(cond, R_NamesSymbol, names);
    SET_STRING_ELT(names, 0, mkChar("message"));
    SET_STRING_ELT(names, 1, mkChar("call"));


    SEXP klass = allocVector(STRSXP, n + 2);
    setAttrib(cond, R_ClassSymbol, klass);
    int i;
    for (i = 0; i < n; i++)
        SET_STRING_ELT(klass, i, mkChar(cls[i]));
    SET_STRING_ELT(klass, i, mkChar("error"));
    SET_STRING_ELT(klass, i + 1, mkChar("condition"));


    UNPROTECT(1);
    return cond;
}


SEXP simpleError(const char *msg, SEXP call)
{
    SEXP cond = PROTECT(allocVector(VECSXP, 2));
    SET_VECTOR_ELT(cond, 0, mkString(msg));
    SET_VECTOR_ELT(cond, 1, call);


    SEXP names = allocVector(STRSXP, 2);
    setAttrib(cond, R_NamesSymbol, names);
    SET_STRING_ELT(names, 0, mkChar("message"));
    SET_STRING_ELT(names, 1, mkChar("call"));


    SEXP klass = allocVector(STRSXP, 3);
    setAttrib(cond, R_ClassSymbol, klass);
    SET_STRING_ELT(klass, 0, mkChar("simpleError"));
    SET_STRING_ELT(klass, 1, mkChar("error"));
    SET_STRING_ELT(klass, 2, mkChar("condition"));


    UNPROTECT(1);
    return cond;
}


SEXP thisPathNotExistsError(const char *msg, SEXP call)
{
    const char *cls[] = {"this.path::thisPathNotExistsError", "this.path::thisPathNotExistError", "this.path_this.path_not_exists_error"};
    return errorCondition(msg, call, cls, 3);
}


SEXP thisPathNotImplementedError(const char *msg, SEXP call)
{
    const char *cls[] = {"this.path::thisPathNotImplementedError", "this.path_this.path_unimplemented_error", "notImplementedError", "NotImplementedError"};
    return errorCondition(msg, call, cls, 4);
}


SEXP thisPathInZipFileError(const char *msg, SEXP call)
{
    const char *cls[] = {"this.path::thisPathInZipFileError"};
    return errorCondition(msg, call, cls, 1);
}


SEXP thisPathUnrecognizedConnectionClassError(const char *msg, SEXP call)
{
    const char *cls[] = {"this.path::thisPathUnrecognizedConnectionClassError"};
    return errorCondition(msg, call, cls, 1);
}


void stop(SEXP cond)
{
    SEXP expr = PROTECT(lang2(install("stop"), cond));
    eval(expr, R_BaseEnv);
    UNPROTECT(1);
    return;
}


int in_rstudio = -1;


#ifdef Win32
#define isclipboard(url) (                                             \
                              strcmp ((url), "clipboard"     ) == 0 || \
                              strncmp((url), "clipboard-", 10) == 0    \
                         )
#else
#define isclipboard(url) (                                           \
                              strcmp((url), "clipboard"    ) == 0 || \
                              strcmp((url), "X11_primary"  ) == 0 || \
                              strcmp((url), "X11_secondary") == 0 || \
                              strcmp((url), "X11_clipboard") == 0    \
                         )
#endif





static const char *thispathofileChar   = "__this.path::ofile__";
static const char *thispathfileChar    = "__this.path::file__";
static const char *thispathoformsgChar = "__this.path::for msg__";
static SEXP thispathofileSymbol  = NULL;
static SEXP thispathfileSymbol   = NULL;
static SEXP thispathformsgSymbol = NULL;





SEXP _assign(SEXP file, SEXP frame)
{
    INCREMENT_NAMED(file);
    defineVar(thispathofileSymbol, file, frame);
    /* this would be so much easier if we were given access to mkPROMISE */
    eval(lang5(findVarInFrame(R_BaseEnv, install("delayedAssign")),
/* x          */    mkString(thispathfileChar),
/* value      */    R_NilValue,
/* eval.env   */    R_EmptyEnv,
/* assign.env */    frame
    ), R_EmptyEnv);
    return findVarInFrame(frame, thispathfileSymbol);
}


void assign_default(SEXP file, SEXP frame, SEXP rho)
{
    SEXP e = _assign(file, frame);
    SEXP expr = lang4(findVarInFrame(R_BaseEnv, install("normalizePath")),
        file,
        mkString("/"),
        ScalarLogical(TRUE)
    );
    SET_TAG(CDDR(expr), install("winslash"));
    SET_TAG(CDDDR(expr), install("mustWork"));
    SET_PRCODE(e, expr);
    return;
}


void assign_null(SEXP frame)
{
    /* make and force the promise */
    eval(_assign(R_NilValue, frame), R_EmptyEnv);
}


void assign_fileurl(SEXP ofile, SEXP file, SEXP frame, SEXP rho)
{
    SEXP e = _assign(ofile, frame);


    /* translate the string, then extract the string after file://
     * or file:/// on windows where path is file:///d:/path/to/file */
    const char *url;
    cetype_t ienc;
#ifdef Win32
    if (!IS_ASCII(file)) {
        ienc = CE_UTF8;
        url = trCharUTF8(file);
    } else {
        ienc = getCharCE(file);
        url = CHAR(file);
    }
#else
    ienc = getCharCE(file);
    url = CHAR(file);
#endif


#ifdef Win32
    if (strlen(url) > 9 && url[7] == '/' && url[9] == ':')
        url += 8;
    else url += 7;
#else
    url += 7;
#endif


    SEXP expr = lang4(findVarInFrame(R_BaseEnv, install("normalizePath")),
        ScalarString(mkCharCE(url, ienc)),
        mkString("/"),
        ScalarLogical(TRUE)
    );
    SET_TAG(CDDR(expr), install("winslash"));
    SET_TAG(CDDDR(expr), install("mustWork"));
    SET_PRCODE(e, expr);
    return;
}


void assign_fileurl2(SEXP description, SEXP frame, SEXP rho)
{
    char _buf[7 + strlen(CHAR(description)) + 1];
    char *buf = _buf;
    strcpy(buf, "file://");
    buf += 7;
    strcpy(buf, CHAR(description));


    SEXP ofile = ScalarString(mkCharCE(buf, getCharCE(description)));


    SEXP e = _assign(ofile, frame);


    SEXP expr = lang4(findVarInFrame(R_BaseEnv, install("normalizePath")),
        ScalarString(description),
        mkString("/"),
        ScalarLogical(TRUE)
    );
    SET_TAG(CDDR(expr), install("winslash"));
    SET_TAG(CDDDR(expr), install("mustWork"));
    SET_PRCODE(e, expr);
    return;
}


void assign_url(SEXP ofile, SEXP file, SEXP frame, SEXP rho)
{
    SEXP e = _assign(ofile, frame);


#ifdef Win32
    if (!IS_ASCII(file))
        ofile = ScalarString(mkCharCE(trCharUTF8(file), CE_UTF8));
#endif


    SET_PRCODE(e, lang2(
        install("normalizeURL.1"),
        ofile
    ));
    SET_PRENV(e, rho);


    /* force the promise */
    eval(e, R_EmptyEnv);
}


#define checkfile(name, ofile, frame, character_only, file_only, rho, forcepromise)\
{                                                              \
    if (TYPEOF(ofile) == STRSXP) {                             \
        if (LENGTH(ofile) != 1)                                \
            error("invalid '%s', must be a character string", name);\
        SEXP file = STRING_ELT(ofile, 0);                      \
        if (file == NA_STRING)                                 \
            error("invalid '%s', must not be NA", name);       \
        const char *url = CHAR(file);                          \
        if (!(LENGTH(file) > 0)) {                             \
            if (file_only)                                     \
                error("invalid '%s', must not be \"\"", name); \
            assign_null(frame);                                \
        }                                                      \
        else if (isclipboard(url) || strcmp(url, "stdin") == 0) {\
            if (file_only)                                     \
                error("invalid '%s', must not be \"clipboard\" nor \"stdin\"", name);\
            assign_null(frame);                                \
        }                                                      \
        else if (strncmp(url, "http://", 7) == 0 ||            \
                 strncmp(url, "https://", 8) == 0 ||           \
                 strncmp(url, "ftp://", 6) == 0 ||             \
                 strncmp(url, "ftps://", 7) == 0)              \
        {                                                      \
            if (file_only)                                     \
                error("invalid '%s', cannot be a URL", name);  \
            assign_url(ofile, file, frame, rho);               \
        }                                                      \
        else if (strncmp(url, "file://", 7) == 0) {            \
            if (file_only)                                     \
                error("invalid '%s', cannot be a file URL", name);\
            assign_fileurl(ofile, file, frame, rho);           \
        }                                                      \
        else {                                                 \
            assign_default(ofile, frame, rho);                 \
        }                                                      \
        if (forcepromise) {                                    \
            SEXP tmp = eval(findVarInFrame(frame, thispathfileSymbol), rho);\
            INCREMENT_NAMED(tmp);                              \
            defineVar(thispathformsgSymbol, tmp, frame);       \
        }                                                      \
    }                                                          \
    else {                                                     \
        if (character_only)                                    \
            error("invalid '%s', must be a character string", name);\
        if (!inherits(ofile, "connection"))                     \
            error("invalid '%s', must be a string or connection", name);\
        SEXP expr = lang2(findVarInFrame(R_BaseEnv, install("summary.connection")), ofile);\
        PROTECT(expr);                                         \
        SEXP summary = eval(expr, R_EmptyEnv);                 \
        UNPROTECT(1);                                          \
        PROTECT(summary);                                      \
        SEXP description  =      STRING_ELT(VECTOR_ELT(summary, 0), 0) ;\
        const char *klass = CHAR(STRING_ELT(VECTOR_ELT(summary, 1), 0));\
                                                               \
                                                               \
        if (streql(klass, "file")   ||                         \
            streql(klass, "gzfile") ||                         \
            streql(klass, "bzfile") ||                         \
            streql(klass, "xzfile") ||                         \
            streql(klass, "fifo"))                             \
        {                                                      \
            assign_fileurl2(description, frame, rho);          \
            if (forcepromise) {                                \
                SEXP tmp = eval(findVarInFrame(frame, thispathfileSymbol), rho);\
                INCREMENT_NAMED(tmp);                          \
                defineVar(thispathformsgSymbol, tmp, frame);   \
            }                                                  \
        }                                                      \
        else if (streql(klass, "url-libcurl") ||               \
                 streql(klass, "url-wininet"))                 \
        {                                                      \
            if (file_only)                                     \
                error("invalid '%s', cannot be a URL connection", name);\
            assign_url(ScalarString(description), description, frame, rho);\
            if (forcepromise) {                                \
                SEXP tmp = eval(findVarInFrame(frame, thispathfileSymbol), rho);\
                INCREMENT_NAMED(tmp);                          \
                defineVar(thispathformsgSymbol, tmp, frame);   \
            }                                                  \
        }                                                      \
        else if (streql(klass, "terminal")  ||                 \
                 streql(klass, "clipboard") ||                 \
                 streql(klass, "pipe"))                        \
        {                                                      \
            if (file_only)                                     \
                error("invalid '%s', cannot be a terminal / / clipboard / / pipe connection", name);\
            assign_null(frame);                                \
        }                                                      \
        else if (streql(klass, "unz")) {                       \
            SEXP tmp = eval(lang2(                             \
                install("thisPathInZipFileError"),             \
                mkString("'this.path' cannot be used within a zip file")\
            ), rho);                                           \
            INCREMENT_NAMED(tmp);                              \
            defineVar(thispathformsgSymbol, tmp, frame);       \
        }                                                      \
        else {                                                 \
            SEXP tmp = eval(lang3(                             \
                install("thisPathUnrecognizedConnectionClassError"),\
                mkString("'this.path' not implemented when source-ing a connection of class "),\
                mkString(klass)                                \
            ), rho);                                           \
            INCREMENT_NAMED(tmp);                              \
            defineVar(thispathformsgSymbol, tmp, frame);       \
        }                                                      \
    }                                                          \
    defineVar(install("done"), ScalarLogical(TRUE), rho);      \
}


SEXP do_thispath(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    if (thispathofileSymbol == NULL) {
        thispathofileSymbol  = install(thispathofileChar);
        thispathfileSymbol   = install(thispathfileChar);
        thispathformsgSymbol = install(thispathoformsgChar);
    }


    SEXP thispathofile,
         thispathfile,
         thispathformsg;


    int nprotect = 0;


    int testthat_loaded, knitr_loaded;


    SEXP source = findVarInFrame(R_BaseEnv, install("source"));
    SEXP sys_source = findVarInFrame(R_BaseEnv, install("sys.source"));
    SEXP tools_rstudio;
    SEXP debugSource, source_file, knit;


    args = CDR(args);


    int verbose  = asFlag(CAR(args), "verbose");
    int original = asFlag(CADR(args), "original");
    int for_msg  = asFlag(CADDR(args), "for.msg");
    int N        = asInteger(CADDDR(args));
    int get_frame_number = asFlag(CAD4R(args), "get.frame.number");


    if (in_rstudio == -1) {
        in_rstudio = asLogical(eval(install("gui.rstudio"), rho));
    }
    if (in_rstudio) {
        tools_rstudio = matchEnvir("tools:rstudio");
        debugSource = findVarInFrame(tools_rstudio, install("debugSource"));
        if (debugSource == R_UnboundValue)
            error(_("object '%s' not found"), "debugSource");
        if (TYPEOF(debugSource) == PROMSXP) {
            if (PRVALUE(debugSource) == R_UnboundValue)
                debugSource = eval(debugSource, rho);
            else
                debugSource = PRVALUE(debugSource);
        }
        if (TYPEOF(debugSource) != CLOSXP)
            error(_("object '%s' of mode '%s' was not found"), "debugSource", "function");
    }
    else debugSource = R_NilValue;


    testthat_loaded = (findVarInFrame(R_NamespaceRegistry, install("testthat")) != R_UnboundValue);
    if (testthat_loaded)
        source_file = R_getNSValue(R_NilValue, install("testthat"), install("source_file"), TRUE);
    else
        source_file = R_NilValue;


    knitr_loaded = (findVarInFrame(R_NamespaceRegistry, install("knitr")) != R_UnboundValue);
    if (knitr_loaded)
        knit = R_getNSValue(R_NilValue, install("knitr"), install("knit"), TRUE);
    else
        knit = R_NilValue;


// #define identical(x, y) R_compute_identical((x), (y), 47)
#define identical(x, y) ((x) == (y))


    SEXP which = allocVector(INTSXP, 1);
    SEXP getframe = lang2(findVarInFrame(R_BaseEnv, install("sys.frame")), which);
    PROTECT(getframe); nprotect++;
    SEXP getfunction = lang2(findVarInFrame(R_BaseEnv, install("sys.function")), which);
    PROTECT(getfunction); nprotect++;


    int *iwhich = INTEGER(which);


    SEXP frame, function;
    SEXP ofile;
    SEXP returnthis = NULL;
    for (int n = N; n >= 1; n--) {
        iwhich[0] = n;
        frame = eval(getframe, R_EmptyEnv);
        function = eval(getfunction, R_EmptyEnv);
        if (identical(function, source)) {
            thispathofile = findVarInFrame(frame, thispathofileSymbol);
            if (thispathofile == R_UnboundValue) {
                ofile = findVarInFrame(frame, install("ofile"));
                if (ofile == R_UnboundValue)
                    continue;
                if (TYPEOF(ofile) == PROMSXP) {
                    if (PRVALUE(ofile) == R_UnboundValue)
                        ofile = eval(ofile, R_EmptyEnv);
                    else
                        ofile = PRVALUE(ofile);
                }
                checkfile(
                    /* const char *name   = */ "ofile",
                    /* SEXP ofile         = */ ofile,
                    /* SEXP frame         = */ frame,
                    /* int character_only = */ FALSE,
                    /* int file_only      = */ FALSE,
                    /* SEXP rho           = */ rho  ,
                    /* int forcepromise   = */ FALSE
                )
                thispathofile = findVarInFrame(frame, thispathofileSymbol);
            }
            if (thispathofile == R_NilValue)
                continue;
            thispathformsg = findVarInFrame(frame, thispathformsgSymbol);
            /* if there is an error which needs to be thrown */
            if (thispathformsg != R_UnboundValue) {
                if (for_msg) {
                    eval(lang2(
                        install("return"),
                        ScalarString(NA_STRING)
                    ), rho);
                }
                else {
                    thispathformsg = duplicate(thispathformsg);
                    SET_VECTOR_ELT(thispathformsg, 1, call);
                    stop(thispathformsg);
                }
                /* should not reach here */
                UNPROTECT(nprotect);
                return R_NilValue;
            }
            if (for_msg) {
                thispathfile = findVarInFrame(frame, thispathfileSymbol);
                if (thispathfile == R_UnboundValue)
                    error(_("object '%s' not found"), thispathfileChar);
                if (TYPEOF(thispathfile) != PROMSXP)
                    error("invalid '%s', is not a promise; should never happen, please report!");
                eval(lang2(
                    install("return"),
                    (PRVALUE(thispathfile) != R_UnboundValue) ? thispathfile : thispathofile
                ), rho);
                /* should not reach here */
                UNPROTECT(nprotect);
                return R_NilValue;
            }
            if (get_frame_number) {
                eval(lang2(install("return"), ScalarInteger(n)), rho);
                /* should not reach here */
                UNPROTECT(nprotect);
                return R_NilValue;
            }
            if (original)
                returnthis = thispathofile;
            else {
                thispathfile = findVarInFrame(frame, thispathfileSymbol);
                if (TYPEOF(thispathfile) != PROMSXP)
                    error("invalid '%s', is not a promise; should never happen, please report!");
                if (PRVALUE(thispathfile) == R_UnboundValue)
                    returnthis = eval(thispathfile, R_EmptyEnv);
                else
                    returnthis = PRVALUE(returnthis);
            }
            if (verbose)
                Rprintf("Source: call to function source\n");
            eval(lang2(
                install("return"),
                returnthis
            ), rho);
            /* should not reach here */
            UNPROTECT(nprotect);
            return R_NilValue;
        }
    }


    UNPROTECT(nprotect);
    return R_NilValue;
}


SEXP do_errorcondition(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    const char *cls[] = {"this.path::thisPathNotExistsError", "this.path::thisPathNotExistError", "this.path_this.path_not_exists_error"};
    return errorCondition("testing msg", call, cls, 3);
}
