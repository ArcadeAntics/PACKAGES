#include <R.h>
#include <Rinternals.h>


#include "thispathdefn.h"


SEXP do_makepromise(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    int nprotect = 0;


    SEXP expr, env;
    int seen;
    SEXP value;
    switch (length(args) - 1) {
    case 2:
        expr  = CADR(args);
        env   = R_EmptyEnv;
        seen  = 0;
        value = CADDR(args);
        break;
    case 3:
        expr  = CADR(args);
        env   = CADDR(args);
        if (!isEnvironment(env))
            errorcall(call, "invalid second argument, must be an environment");
        seen  = asInteger(CADDDR(args));
        value = R_UnboundValue;
        break;
    default:
        errorcall(call, "%d arguments passed to .External(%s) which requires 2 or 3",
            length(args) - 1, "C_makepromise");
    }


    SEXP assign_env = R_NewEnv(R_EmptyEnv, TRUE, 1);
    PROTECT(assign_env); nprotect++;
    SEXP tmp = lang5(
        findVarInFrame(R_BaseEnv, install("delayedAssign")),
        mkString("x"),
        expr,
        env,
        assign_env
    );
    PROTECT(tmp); nprotect++;
    eval(tmp, R_EmptyEnv);
    set_R_Visible(1);


    SEXP promise = findVarInFrame(assign_env, install("x"));
    if (promise == R_UnboundValue ||
        TYPEOF(promise) != PROMSXP)
    {
        error("'x' is not a promise; should never happen, please report!");
    }


    if (value == R_UnboundValue) {
        SET_PRSEEN(promise, seen);
        // SET_PRVALUE(promise, value);
        // SET_PRENV(promise, env);
    } else {
        SET_PRSEEN(promise, 0);
        SET_PRVALUE(promise, value);
        SET_PRENV(promise, R_NilValue);
    }


    UNPROTECT(nprotect);
    return promise;
}


SEXP do_setprseen2(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    const char *name = "promises";
    SEXP promises = findVarInFrame(rho, install(name));
    if (promises == R_UnboundValue)
        error(_("object '%s' not found"), name);
    /* 'promises' is an empty pairlist, so nothing to do */
    if (TYPEOF(promises) == NILSXP)
        return R_NilValue;
    if (TYPEOF(promises) != LISTSXP)
        error("invalid '%s', must be a pairlist", name);
    SEXP x, p;
    for (x = promises ; x != R_NilValue ; x = CDR(x)) {
        p = CAR(x);
        if (TYPEOF(p) != PROMSXP)
            error("invalid '%s', must be a pairlist of promises, not type '%s'", name, type2char(TYPEOF(p)));
        if (PRSEEN(p) != 1)
            error("invalid '%s', contains a promise in which PRSEEN is not 1");
        if (PRVALUE(p) != R_UnboundValue)
            error("invalid '%s', contains a promise in which PRVALUE is defined");
    }
    /* now that we know the list is safe to modify, change all the PRSEEN
       value to 2, the value used for interupted promises */
    for (x = promises ; x != R_NilValue ; x = CDR(x))
        SET_PRSEEN(CAR(x), 2);
    return R_NilValue;
}


void validatefile(SEXP ofile, SEXP frame, int character_only, int file_only, SEXP rho)
{
    const char *name = "file";
    if (TYPEOF(ofile) == STRSXP) {
        if (LENGTH(ofile) != 1)
            error("invalid '%s', must be a character string", name);
        SEXP file = STRING_ELT(ofile, 0);
        if (file == NA_STRING)
            error("invalid '%s', must not be NA", name);
        const char *url = CHAR(file);
        if (!(LENGTH(file) > 0)) {
            if (file_only)
                error("invalid '%s', must not be \"\"", name);
            assign_null(frame);
        }
        else if (strcmp(url, "clipboard") == 0 ||
                 strcmp(url, "stdin") == 0 ||
#ifdef Win32
                 strncmp(url, "clipboard-", 10) == 0
#else
                 strcmp(url, "X11_primary") == 0 ||
                 strcmp(url, "X11_secondary") == 0 ||
                 strcmp(url, "X11_clipboard") == 0
#endif
        ) {
            if (file_only)
                error("invalid '%s', must not be \"clipboard\" nor \"stdin\"", name);
            assign_null(frame);
        }
        else if (strncmp(url, "http://", 7) == 0 ||
                 strncmp(url, "https://", 8) == 0 ||
                 strncmp(url, "ftp://", 6) == 0 ||
                 strncmp(url, "ftps://", 7) == 0)
        {
            if (file_only)
                error("invalid 'file', cannot be a URL");
            assign_url(ofile, file, frame, rho);
        }
        else if (strncmp(url, "file://", 7) == 0) {
            if (file_only)
                error("invalid 'file', cannot be a file URL");
            assign_fileurl(ofile, file, frame, rho);
        }
        else {
            assign_default(ofile, frame, rho);
        }
#define forcepromise eval(findVarInFrame(frame, install("__this.path::file__")), rho)


        forcepromise;
    }
    else {
        if (character_only)
            errorcall(R_CurrentExpression, "invalid '%s', must be a character string", name);
        if (!inherits(ofile, "connection"))
            errorcall(R_CurrentExpression, "invalid '%s', must be a string or connection", name);
        Rconnection Rcon = R_GetConnection(ofile);
        SEXP description;
        if (Rcon->enc == CE_UTF8)
            description = mkCharCE(Rcon->description, CE_UTF8);
        else
            description = mkChar(Rcon->description);
        const char *klass = Rcon->class;


        if (streql(klass, "file")   ||
            streql(klass, "gzfile") ||
            streql(klass, "bzfile") ||
            streql(klass, "xzfile") ||
            streql(klass, "fifo"))
        {
            assign_fileurl2(description, frame, rho);
            forcepromise;
        }
        else if (streql(klass, "url-libcurl") ||
                 streql(klass, "url-wininet"))
        {
            if (file_only)
                error("invalid 'file', cannot be a URL connection");
            assign_url(ScalarString(description), description, frame, rho);
            forcepromise;
        }
        else if (streql(klass, "terminal")  ||
                 streql(klass, "clipboard") ||
                 streql(klass, "pipe"))
        {
            if (file_only)
                error("invalid 'file', cannot be a terminal / / clipboard / / pipe connection");
            assign_null(frame);
        }
        else if (streql(klass, "unz")) {
            error("bruh 1");
        }
        else error("bruh 2");
    }
    defineVar(install("__this.path::done__"), R_NilValue, frame);
    R_LockBinding(install("__this.path::done__"), frame);
    return;
}


SEXP findfiletheneval(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    int nprotect = 0;
    const char *name = "expr";


    int character_only, file_only;


    character_only = asLogical(CADR(args));
    if (character_only == NA_LOGICAL)
        error(_("invalid '%s' argument"), "character.only");
    file_only = asLogical(CADDR(args));
    if (file_only == NA_LOGICAL)
        error(_("invalid '%s' argument"), "file.only");


    SEXP promise = findVarInFrame(rho, install(name));
    if (promise == R_UnboundValue) {
        const char *format = _("object '%s' not found");
        char str[strlen(format) + strlen(name) + 1];
        sprintf(str, format, name);
        error("%s; should never happen, please report!", str);
    }
    if (TYPEOF(promise) != PROMSXP)
        error("invalid '%s', must be a promise; should never happen, please report!", name);


    SEXP promises = R_NilValue;
    PROTECT_INDEX indx;
    PROTECT_WITH_INDEX(promises, &indx); nprotect++;


    /* we will be modifying the PRSEEN values of the promises,
     * but we need to change them to 0 or 2 depending upon whether
     * this returns a value as normal or the promises get interupted
     *
     * save the root promise, the original code of the promise,
     * and make an on.exit() call that will restore said promise
     */
    defineVar(install("promises"), promises, rho);
    eval(lang2(
        install("on.exit"),
        lang2(
            install(".External2"),
            install("C_setprseen2")
        )
    ), rho);


#define check_validity                                         \
    do {                                                       \
        if (PRVALUE(promise) != R_UnboundValue)                \
            error("invalid '%s', must be a call when '%s' is missing", name, "file");\
        REPROTECT(promises = CONS(promise, promises), indx);   \
        if (PRSEEN(promise)) {                                 \
            if (PRSEEN(promise) == 1)                          \
                error(_("promise already under evaluation: recursive default argument reference or earlier problems?"));\
            else {                                             \
                SET_PRSEEN(promise, 1);                        \
                warning(_("restarting interrupted promise evaluation"));\
            }                                                  \
        }                                                      \
        else SET_PRSEEN(promise, 1);                           \
    } while (0)


#define set_prvalues_then_return(val)                          \
    do {                                                       \
        for (SEXP x = promises ; x != R_NilValue ; x = CDR(x)) {\
            SEXP p = CAR(x);                                   \
            SET_PRSEEN (p, 0);                                 \
            SET_PRVALUE(p, (val));                             \
            ENSURE_NAMEDMAX((val));                            \
            SET_PRENV  (p, R_NilValue);                        \
        }                                                      \
        /* remove the previous on.exit() */                    \
        eval(lang1(install("on.exit")), rho);                  \
        UNPROTECT(nprotect);                                   \
        return (val);                                          \
    } while (0)


    check_validity;


    /* find the root promise */
    while (TYPEOF(PREXPR(promise)) == PROMSXP) {
        promise = PREXPR(promise);
        check_validity;
    }


    SEXP expr = PREXPR(promise),
         env  = PRENV (promise);


    if (TYPEOF(expr) != LANGSXP)
        error("invalid '%s', must be a call when '%s' is missing", name, "file");


    if (length(expr) < 2) {
        SEXP val = eval(PRCODE(promise), env);
        set_prvalues_then_return(val);
    }


    SEXP oexpr = expr;
    expr = duplicate(expr);
    PROTECT(expr); nprotect++;


    SEXP fun     = CAR(expr),
         funargs = CDR(expr);
    if (TYPEOF(fun) == SYMSXP)
        fun = findFun3(fun, env, expr);
    else
        fun = eval(fun, env);
    PROTECT(fun); nprotect++;


    switch (TYPEOF(fun)) {
    case SPECIALSXP:
    case BUILTINSXP:
    case CLOSXP:
        break;
    default:
        error(_("attempt to apply non-function"));
    }


    /* change the function so that it is not evaluated twice */
    SETCAR(expr, fun);


    SEXP s, b, dots, dot;
    int already_checked_dots;


    SEXP tag;
    if (TYPEOF(fun) == CLOSXP)
        tag = TAG(FORMALS(fun));
    else
        tag = R_NilValue;


    int i, n = -1;


    if (tag != R_NilValue && tag != R_DotsSymbol) {


        s = NULL;
        dots = NULL;
        /* exact matches */
        already_checked_dots = 0;
        for (b = funargs, i = 0 ; b != R_NilValue ; b = CDR(b), i++) {
            if (CAR(b) == R_DotsSymbol) {
                if (already_checked_dots)
                    continue;
                already_checked_dots = 1;
                dots = findVar(R_DotsSymbol, env);
                if (TYPEOF(dots) == DOTSXP) {
                    for (dot = dots ; dot != R_NilValue ; dot = CDR(dot)) {
                        if (TAG(dot) != R_NilValue && pmatch(tag, TAG(dot), 1)) {
                            if (s != NULL)
                                errorcall(oexpr, _("formal argument \"%s\" matched by multiple actual arguments"), CHAR(PRINTNAME(tag)));
                            else
                                s = CAR(dot);
                            if (TYPEOF(s) != PROMSXP)
                                error(_("value in '...' is not a promise"));
                        }
                    }
                }
                else if (dots != R_NilValue && dots != R_MissingArg)
                    error(_("'...' used in an incorrect context"));
            }
            else if (TAG(b) != R_NilValue && pmatch(tag, TAG(b), 1)) {
                if (s != NULL)
                    errorcall(oexpr, _("formal argument \"%s\" matched by multiple actual arguments"), CHAR(PRINTNAME(tag)));
                else
                    s = CAR(b);
                n = i;
            }
        }


        if (s == NULL) {
            /* partial matches */
            already_checked_dots = 0;
            for (b = funargs, i = 0 ; b != R_NilValue ; b = CDR(b), i++) {
                if (CAR(b) == R_DotsSymbol) {
                    if (already_checked_dots)
                        continue;
                    already_checked_dots = 1;
                    if (TYPEOF(dots) == DOTSXP) {
                        for (dot = dots ; dot != R_NilValue ; dot = CDR(dot)) {
                            if (TAG(dot) != R_NilValue && pmatch(tag, TAG(dot), 0)) {
                                if (s != NULL)
                                    errorcall(oexpr, _("formal argument \"%s\" matched by multiple actual arguments"), CHAR(PRINTNAME(tag)));
                                else
                                    s = CAR(dot);
                                if (TYPEOF(s) != PROMSXP)
                                    error(_("value in '...' is not a promise"));
                            }
                        }
                    }
                    else if (dots != R_NilValue && dots != R_MissingArg)
                        error(_("'...' used in an incorrect context"));
                }
                else if (TAG(b) != R_NilValue && pmatch(tag, TAG(b), 0)) {
                    if (s != NULL)
                        errorcall(oexpr, _("formal argument \"%s\" matched by multiple actual arguments"), CHAR(PRINTNAME(tag)));
                    else
                        s = CAR(b);
                    n = i;
                }
            }
        }


        if (s == NULL) {
            /* first untagged argument */
            already_checked_dots = 0;
            for (b = funargs, i = 0 ; b != R_NilValue ; b = CDR(b), i++) {
                if (CAR(b) == R_DotsSymbol) {
                    if (already_checked_dots)
                        continue;
                    already_checked_dots = 1;
                    if (TYPEOF(dots) == DOTSXP) {
                        for (dot = dots ; dot != R_NilValue ; dot = CDR(dot)) {
                            if (TAG(dot) == R_NilValue) {
                                s = CAR(dot);
                                if (TYPEOF(s) != PROMSXP)
                                    error(_("value in '...' is not a promise"));
                                break;
                            }
                        }
                        if (s != NULL) break;  /* break out of both for loops */
                    }
                    else if (dots != R_NilValue && dots != R_MissingArg)
                        error(_("'...' used in an incorrect context"));
                }
                else if (TAG(b) == R_NilValue) {
                    s = CAR(b);
                    n = i;
                    break;
                }
            }
        }
    }
    else {
        s = NULL;
        dots = NULL;
        already_checked_dots = 0;
        for (b = funargs, i = 0 ; b != R_NilValue ; b = CDR(b), i++) {
            if (CAR(b) == R_DotsSymbol) {
                if (already_checked_dots)
                    continue;
                already_checked_dots = 1;
                dots = findVar(R_DotsSymbol, env);
                if (TYPEOF(dots) == DOTSXP) {
                    s = CAR(dots);
                    if (TYPEOF(s) != PROMSXP)
                        error(_("value in '...' is not a promise"));
                    break;
                }
                else if (dots != R_NilValue && dots != R_MissingArg)
                    error(_("'...' used in an incorrect context"));
            }
            else {
                s = CAR(b);
                n = i;
                break;
            }
        }
    }
    if (s == NULL) {
        if (character_only || file_only)
            errorcall(oexpr, "argument '%s' is missing", CHAR(PRINTNAME(tag)));
        SEXP tmp = eval(expr, env);
        set_prvalues_then_return(tmp);
    }


    SEXP e;


    switch (TYPEOF(s)) {
    case PROMSXP:
        e = eval(s, env);
        break;
    case SYMSXP:
    case LANGSXP:
        if (n == -1)
            error("found a symbol / / call but not an index; should never happen, please report!");
        e = eval(s, env);


        SEXP aenv = R_NewEnv(R_EmptyEnv, TRUE, 1);
        PROTECT(aenv); nprotect++;


        SEXP tmp = lang5(
            findVarInFrame(R_BaseEnv, install("delayedAssign")),
            mkString("x"),
            R_NilValue,
            R_EmptyEnv,
            aenv
        );
        PROTECT(tmp); nprotect++;


        eval(tmp, R_EmptyEnv);
        tmp = findVarInFrame(aenv, install("x"));
        SET_PRCODE(tmp, s);
        SET_PRSEEN(tmp, 0);
        SET_PRVALUE(tmp, e);
        ENSURE_NAMEDMAX(e);
        SET_PRENV(tmp, R_NilValue);


        e = tmp;
        /* add 1 for the function at the start */
        SETCAR(nthcdr(expr, n + 1), e);
        break;
    default:
        e = s;
        break;
    }


    e = TYPEOF(e) == PROMSXP ? PRVALUE(e) : e;
    checkfile(
        /* const char *name   = */ "file",
        /* SEXP ofile         = */ e    ,
        /* SEXP frame         = */ rho  ,
        /* int character_only = */ character_only,
        /* int file_only      = */ file_only,
        /* SEXP rho           = */ rho  ,
        /* int forcepromise   = */ TRUE ,
        /* SEXP call          = */ R_CurrentExpression,
        /* int maybe_chdir    = */ FALSE,
        /* SEXP getowd        = */ NULL ,
        /* int hasowd         = */ FALSE,
        /* int do_enc2utf8    = */ FALSE,
        /* int normalize      = */ FALSE
    )
    SEXP tmp = eval(expr, env);
    set_prvalues_then_return(tmp);
}


SEXP do_wrapsource(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    SEXP file;
    int character_only, file_only;


    int nargs = length(args) - 1;
    switch (nargs) {
    case 2:
        return findfiletheneval(call, op, args, rho);
    case 3:
        file = CADR(args);
        character_only = asLogical(CADDR(args));
        if (character_only == NA_LOGICAL)
            error(_("invalid '%s' argument"), "character.only");
        file_only = asLogical(CADDDR(args));
        if (file_only == NA_LOGICAL)
            error(_("invalid '%s' argument"), "file.only");
        checkfile(
            /* const char *name   = */ "file",
            /* SEXP ofile         = */ file ,
            /* SEXP frame         = */ rho  ,
            /* int character_only = */ character_only,
            /* int file_only      = */ file_only,
            /* SEXP rho           = */ rho  ,
            /* int forcepromise   = */ TRUE ,
            /* SEXP call          = */ R_CurrentExpression,
            /* int maybe_chdir    = */ FALSE,
            /* SEXP getowd        = */ NULL ,
            /* int hasowd         = */ FALSE,
            /* int do_enc2utf8    = */ FALSE,
            /* int normalize      = */ FALSE
        )
        return eval(install("expr"), rho);
    default:
        error(
            nargs == 1 ? "%d argument passed to .External(%s) which requires %s" :
                         "%d arguments passed to .External(%s) which requires %s",
            nargs, "C_wrapsource", "2 or 3"
        );
    }


    return R_NilValue;
}


SEXP do_withinsource(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    SEXP file, frame;
    int character_only, file_only;


    file = CADR(args);
    character_only = asLogical(CADDR(args));
    if (character_only == NA_LOGICAL)
        error(_("invalid '%s' argument"), "character.only");
    file_only = asLogical(CADDDR(args));
    if (file_only == NA_LOGICAL)
        error(_("invalid '%s' argument"), "file.only");
    frame = CAD4R(args);
    if (TYPEOF(frame) != ENVSXP)
        error(_("invalid '%s' argument"), "frame");


    checkfile(
        /* const char *name   = */ "file",
        /* SEXP ofile         = */ file ,
        /* SEXP frame         = */ frame,
        /* int character_only = */ character_only,
        /* int file_only      = */ file_only,
        /* SEXP rho           = */ rho  ,
        /* int forcepromise   = */ TRUE ,
        /* SEXP call          = */ R_CurrentExpression,
        /* int maybe_chdir    = */ FALSE,
        /* SEXP getowd        = */ NULL ,
        /* int hasowd         = */ FALSE,
        /* int do_enc2utf8    = */ FALSE,
        /* int normalize      = */ FALSE
    )
    defineVar(withinsourcewashereSymbol, R_NilValue, frame);
    R_LockBinding(withinsourcewashereSymbol, frame);
    set_R_Visible(0);
    return R_NilValue;
}
