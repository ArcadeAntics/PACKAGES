wrap.source <- function (expr, file, character.only = FALSE, file.only = FALSE)
{
    if (missing(file))
        .External2(C_wrapsource, character.only, file.only)
    else .External2(C_wrapsource, file, character.only, file.only)
}


    # if (sys.nframe() < 2L)
    #     stop("'within.source' can only be used within a function")
within.source <- function (file, character.only = FALSE, file.only = FALSE)
.External2(C_withinsource, file, character.only, file.only)
