#include <R.h>
#include <Rinternals.h>


#define set_R_Visible(v) (eval((v) ? R_NilValue : lang1(install("invisible")), R_BaseEnv))


SEXP do_validatefile(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    SEXP file = CADR(args);
    if (!isString(file) || LENGTH(file) != 1)
        error("invalid 'file', must be a character string");
    if (STRING_ELT(file, 0) == NA_STRING)
        error("invalid 'file', must not be NA");
    return R_NilValue;
}


// SEXP do_testing2(SEXP call, SEXP op, SEXP args, SEXP rho)
// {
//     SEXP dots = findVarInFrame(rho, install("..."));
//     if (dots == R_UnboundValue)
//         error("unable to find the ... list");
//
//
//     int nprotect = 0,
//         dots_length = ((TYPEOF(dots) == DOTSXP) ? length(dots) : 0),
//         dots_length_expected = 1;
//
//
//     if (dots_length_expected == -1) {}
//     else if (dots_length != dots_length_expected)
//         error("incorrect number of arguments (%d), expecting %d in the ... list",
//                                               dots_length,   dots_length_expected);
//
//
//     SEXP sym = CAR(dots);
//     if (TYPEOF(sym) == PROMSXP) sym = PREXPR(sym);
//     if (TYPEOF(sym) == SYMSXP) {}
//     else if (isValidStringF(sym)) {
//         if (XLENGTH(sym) > 1)
//             errorcall(call, "first argument has length > 1");
//         sym = installTrChar(STRING_ELT(sym, 0));
//     }
//     else error("invalid first argument");
//
//
//     SEXP expr = lang1(install("parent.frame"));
//     PROTECT(expr); nprotect++;
//     SEXP parent_frame = eval(expr, rho);
//     PROTECT(parent_frame); nprotect++;
//
//
//     SEXP promise = findVarInFrame(parent_frame, sym);
//     if (promise == R_UnboundValue)
//         errorcall(call, "object '%s' not found", CHAR(PRINTNAME(sym)));
//
//
//     if (TYPEOF(promise) != PROMSXP)
//         errorcall(call, "'%s' is not a promise", CHAR(PRINTNAME(sym)));
//
//
//     /*
//      * PRCODE
//      * PRENV
//      * PREXPR
//      * PRSEEN
//      * PRVALUE
//      */
//
//
// #define n 4
// #define allocate_value_and_names(len)                          \
//         value = allocVector(VECSXP, len);                      \
//         PROTECT(value); nprotect++;                            \
//         names = allocVector(STRSXP, len);                      \
//         setAttrib(value, R_NamesSymbol, names);
//
//
//     SEXP value, names;
//     if (PRVALUE(promise) != R_UnboundValue) {
//         allocate_value_and_names(n + 1)
//         SET_VECTOR_ELT(value, n, PRVALUE(promise));
//         SET_STRING_ELT(names, n, mkChar("PRVALUE"));
//     } else {
//         allocate_value_and_names(n)
//     }
//
//
// #undef n
// #undef allocate_value_and_names
//
//
//     SET_VECTOR_ELT(value, 0,               PRCODE(promise) );
//     SET_VECTOR_ELT(value, 1,               PRENV (promise) );
//     SET_VECTOR_ELT(value, 2,               PREXPR(promise) );
//     SET_VECTOR_ELT(value, 3, ScalarInteger(PRSEEN(promise)));
//
//
//     SET_STRING_ELT(names, 0, mkChar("PRCODE"));
//     SET_STRING_ELT(names, 1, mkChar("PRENV" ));
//     SET_STRING_ELT(names, 2, mkChar("PREXPR"));
//     SET_STRING_ELT(names, 3, mkChar("PRSEEN"));
//
//
//     UNPROTECT(nprotect);
//     return value;
//     // return R_NilValue;
// }


extern void (SET_PRSEEN)(SEXP x, int v);
extern void SET_PRVALUE(SEXP x, SEXP v);


SEXP do_makepromise(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    int nprotect = 0;


    SEXP expr, env;
    int seen;
    SEXP value;
    switch (length(args) - 1) {
    case 2:
        expr  = CADR(args);
        env   = R_EmptyEnv;
        seen  = 0;
        value = CADDR(args);
        break;
    case 3:
        expr  = CADR(args);
        env   = CADDR(args);
        if (!isEnvironment(env))
            errorcall(call, "invalid second argument, must be an environment");
        seen  = asInteger(CADDDR(args));
        value = R_UnboundValue;
        break;
    default:
        errorcall(call, "%d arguments passed to .External(%s) which requires 2 or 3",
            length(args) - 1, "C_makepromise");
    }


    SEXP assign_env = R_NewEnv(R_EmptyEnv, TRUE, 1);
    PROTECT(assign_env); nprotect++;
    SEXP tmp = lang5(
        findVarInFrame(R_BaseEnv, install("delayedAssign")),
        mkString("x"),
        expr,
        env,
        assign_env
    );
    PROTECT(tmp); nprotect++;
    eval(tmp, R_EmptyEnv);
    set_R_Visible(1);


    SEXP promise = findVarInFrame(assign_env, install("x"));
    if (promise == R_UnboundValue ||
        TYPEOF(promise) != PROMSXP)
    {
        error("'x' is not a promise; should never happen, please report!");
    }


    if (value == R_UnboundValue) {
        SET_PRSEEN(promise, seen);
        // SET_PRVALUE(promise, value);
        // SET_PRENV(promise, env);
    } else {
        SET_PRSEEN(promise, 0);
        SET_PRVALUE(promise, value);
        SET_PRENV(promise, R_NilValue);
    }


    UNPROTECT(nprotect);
    return promise;
}
