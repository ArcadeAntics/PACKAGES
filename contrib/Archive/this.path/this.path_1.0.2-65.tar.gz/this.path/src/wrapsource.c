#include <R.h>
#include <Rinternals.h>





#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String) dgettext ("R", String)
#else
#define _(String) (String)
#endif





#define set_R_Visible(v) (eval((v) ? R_NilValue : lang1(install("invisible")), R_BaseEnv))
#define streql(str1, str2) (strcmp((str1), (str2)) == 0)


extern SEXP findFun3(SEXP symbol, SEXP rho, SEXP call);
extern int pmatch(SEXP, SEXP, int);


extern void SET_PRCODE (SEXP x, SEXP v);
extern void SET_PRENV  (SEXP x, SEXP v);
extern void SET_PRSEEN (SEXP x, int  v);
extern void SET_PRVALUE(SEXP x, SEXP v);


extern int IS_ASCII(SEXP x);
extern const char *trCharUTF8(SEXP x);


extern void (ENSURE_NAMEDMAX)(SEXP x);


SEXP do_makepromise(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    int nprotect = 0;


    SEXP expr, env;
    int seen;
    SEXP value;
    switch (length(args) - 1) {
    case 2:
        expr  = CADR(args);
        env   = R_EmptyEnv;
        seen  = 0;
        value = CADDR(args);
        break;
    case 3:
        expr  = CADR(args);
        env   = CADDR(args);
        if (!isEnvironment(env))
            errorcall(call, "invalid second argument, must be an environment");
        seen  = asInteger(CADDDR(args));
        value = R_UnboundValue;
        break;
    default:
        errorcall(call, "%d arguments passed to .External(%s) which requires 2 or 3",
            length(args) - 1, "C_makepromise");
    }


    SEXP assign_env = R_NewEnv(R_EmptyEnv, TRUE, 1);
    PROTECT(assign_env); nprotect++;
    SEXP tmp = lang5(
        findVarInFrame(R_BaseEnv, install("delayedAssign")),
        mkString("x"),
        expr,
        env,
        assign_env
    );
    PROTECT(tmp); nprotect++;
    eval(tmp, R_EmptyEnv);
    set_R_Visible(1);


    SEXP promise = findVarInFrame(assign_env, install("x"));
    if (promise == R_UnboundValue ||
        TYPEOF(promise) != PROMSXP)
    {
        error("'x' is not a promise; should never happen, please report!");
    }


    if (value == R_UnboundValue) {
        SET_PRSEEN(promise, seen);
        // SET_PRVALUE(promise, value);
        // SET_PRENV(promise, env);
    } else {
        SET_PRSEEN(promise, 0);
        SET_PRVALUE(promise, value);
        SET_PRENV(promise, R_NilValue);
    }


    UNPROTECT(nprotect);
    return promise;
}


SEXP do_setprseen2(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    const char *name = "promises";
    SEXP promises = findVarInFrame(rho, install(name));
    if (promises == R_UnboundValue)
        error(_("object '%s' not found"), name);
    /* 'promises' is an empty pairlist, so nothing to do */
    if (TYPEOF(promises) == NILSXP)
        return R_NilValue;
    if (TYPEOF(promises) != LISTSXP)
        error("invalid '%s', must be a pairlist", name);
    SEXP x, p;
    for (x = promises ; x != R_NilValue ; x = CDR(x)) {
        p = CAR(x);
        if (TYPEOF(p) != PROMSXP)
            error("invalid '%s', must be a pairlist of promises, not type '%s'", name, type2char(TYPEOF(p)));
        if (PRSEEN(p) != 1)
            error("invalid '%s', contains a promise in which PRSEEN is not 1");
        if (PRVALUE(p) != R_UnboundValue)
            error("invalid '%s', contains a promise in which PRVALUE is defined");
    }
    /* now that we know the list is safe to modify, change all the PRSEEN
       value to 2, the value used for interupted promises */
    for (x = promises ; x != R_NilValue ; x = CDR(x))
        SET_PRSEEN(CAR(x), 2);
    return R_NilValue;
}


SEXP _assign(SEXP file, SEXP frame)
{
    INCREMENT_NAMED(file);
    defineVar(install(".__ofile__"), file, frame);
    /* this would be so much easier if we were given access to mkPROMISE */
    eval(lang5(findVarInFrame(R_BaseEnv, install("delayedAssign")),
/* x          */    mkString(".__file__"),
/* value      */    R_NilValue,
/* eval.env   */    R_EmptyEnv,
/* assign.env */    frame
    ), R_EmptyEnv);
    return findVarInFrame(frame, install(".__file__"));
}


void assign_default(SEXP file, SEXP frame, SEXP rho)
{
    SEXP e = _assign(file, frame);
    SEXP expr = lang4(findVarInFrame(R_BaseEnv, install("normalizePath")),
        file,
        mkString("/"),
        ScalarLogical(TRUE)
    );
    SET_TAG(CDDR(expr), install("winslash"));
    SET_TAG(CDDDR(expr), install("mustWork"));
    SET_PRCODE(e, expr);
    return;
}


void assign_null(SEXP frame)
{
    /* make and force the promise */
    eval(_assign(R_NilValue, frame), R_EmptyEnv);
}


void assign_fileurl(SEXP ofile, SEXP file, SEXP frame, SEXP rho)
{
    SEXP e = _assign(ofile, frame);


    /* translate the string, then extract the string after file://
     * or file:/// on windows where path is file:///d:/path/to/file */
    const char *url;
    cetype_t ienc;
#ifdef Win32
    if (!IS_ASCII(file)) {
        ienc = CE_UTF8;
        url = trCharUTF8(file);
    } else {
        ienc = getCharCE(file);
        url = CHAR(file);
    }
#else
    ienc = getCharCE(file);
    url = CHAR(file);
#endif


#ifdef Win32
    if (strlen(url) > 9 && url[7] == '/' && url[9] == ':')
        url += 8;
    else url += 7;
#else
    url += 7;
#endif


    SEXP expr = lang4(findVarInFrame(R_BaseEnv, install("normalizePath")),
        ScalarString(mkCharCE(url, ienc)),
        mkString("/"),
        ScalarLogical(TRUE)
    );
    SET_TAG(CDDR(expr), install("winslash"));
    SET_TAG(CDDDR(expr), install("mustWork"));
    SET_PRCODE(e, expr);
    return;
}


void assign_fileurl2(SEXP description, SEXP frame, SEXP rho)
{
    char _buf[7 + strlen(CHAR(description)) + 1];
    char *buf = _buf;
    strcpy(buf, "file://");
    buf += 7;
    strcpy(buf, CHAR(description));


    SEXP ofile = ScalarString(mkCharCE(buf, getCharCE(description)));


    SEXP e = _assign(ofile, frame);


    SEXP expr = lang4(findVarInFrame(R_BaseEnv, install("normalizePath")),
        ScalarString(description),
        mkString("/"),
        ScalarLogical(TRUE)
    );
    SET_TAG(CDDR(expr), install("winslash"));
    SET_TAG(CDDDR(expr), install("mustWork"));
    SET_PRCODE(e, expr);
    return;
}


void assign_url(SEXP ofile, SEXP file, SEXP frame, SEXP rho)
{
    SEXP e = _assign(ofile, frame);


#ifdef Win32
    if (!IS_ASCII(file))
        ofile = ScalarString(mkCharCE(trCharUTF8(file), ienc));
#endif


    SET_PRCODE(e, lang2(
        install("normalizeURL.1"),
        ofile
    ));
    SET_PRENV(e, rho);


    /* force the promise */
    eval(e, R_EmptyEnv);
}


void validatefile(SEXP file, SEXP frame, int character_only, int file_only, SEXP rho)
{
    SEXP ofile = file;
    const char *name = "file";
    if (TYPEOF(file) == STRSXP) {
        if (LENGTH(file) != 1)
            error("invalid '%s', must be a character string", name);
        file = STRING_ELT(file, 0);
        if (file == NA_STRING)
            error("invalid '%s', must not be NA", name);
        const char *url = CHAR(file);
        if (!(LENGTH(file) > 0)) {
            if (file_only)
                error("invalid '%s', must not be \"\"", name);
            assign_null(frame);
        }
        else if (strcmp(url, "clipboard") == 0 ||
                 strcmp(url, "stdin") == 0 ||
#ifdef Win32
                 strncmp(url, "clipboard-", 10) == 0
#else
                 strcmp(url, "X11_primary") == 0 ||
                 strcmp(url, "X11_secondary") == 0 ||
                 strcmp(url, "X11_clipboard") == 0
#endif
        ) {
            if (file_only)
                error("invalid '%s', must not be \"clipboard\" nor \"stdin\"", name);
            assign_null(frame);
        }
        else if (strncmp(url, "http://", 7) == 0 ||
                 strncmp(url, "https://", 8) == 0 ||
                 strncmp(url, "ftp://", 6) == 0 ||
                 strncmp(url, "ftps://", 7) == 0)
        {
            if (file_only)
                error("invalid 'file', cannot be a URL");
            assign_url(ofile, file, frame, rho);
        }
        else if (strncmp(url, "file://", 7) == 0) {
            if (file_only)
                error("invalid 'file', cannot be a file URL");
            assign_fileurl(ofile, file, frame, rho);
        }
        else {
            assign_default(ofile, frame, rho);
        }
#define formsg                                                 \
        SEXP tmp = eval(findVarInFrame(frame, install(".__file__")), rho);\
        INCREMENT_NAMED(tmp);                                  \
        defineVar(install("__this.path::for msg__"), tmp, frame);


        formsg
    }
    else {
        if (character_only)
            error(_("a character string argument expected"));
        if (!inherits(file, "connection"))
            error("invalid 'file', must be a string or connection");
        SEXP summary = eval(lang2(install("summary.connection"), ofile), R_BaseEnv);
        PROTECT(summary);
        SEXP names = getAttrib(summary, R_NamesSymbol);
        int n = length(names);


        const char *ss;
        int indx;
#define get_indx                                               \
        indx = -1;                                             \
        for (int i = 0; i < n; i++) {                          \
            if (STRING_ELT(names, i) != NA_STRING) {           \
                if (streql(translateChar(STRING_ELT(names, i)), ss)) {\
                    indx = i;                                  \
                    break;                                     \
                }                                              \
            }                                                  \
        }                                                      \
        if (indx == -1)                                        \
            error("summary.connection() returned a list without an element named '%s'", ss);


        ss = "class";
        get_indx
        const char *Class = CHAR(STRING_ELT(VECTOR_ELT(summary, indx), 0));


        ss = "description";
        get_indx
        SEXP description = STRING_ELT(VECTOR_ELT(summary, indx), 0);


        UNPROTECT(1);


        if (streql(Class, "file")   ||
            streql(Class, "gzfile") ||
            streql(Class, "bzfile") ||
            streql(Class, "xzfile") ||
            streql(Class, "fifo"))
        {
            assign_fileurl2(description, frame, rho);
            formsg
        }
        else if (streql(Class, "url-libcurl") ||
                 streql(Class, "url-wininet"))
        {
            if (file_only)
                error("invalid 'file', cannot be a URL connection");
            assign_url(ScalarString(description), description, frame, rho);
            formsg
        }
        else if (streql(Class, "terminal")  ||
                 streql(Class, "clipboard") ||
                 streql(Class, "pipe"))
        {
            if (file_only)
                error("invalid 'file', cannot be a terminal / / clipboard / / pipe connection");
            assign_null(frame);
        }
        else if (streql(Class, "unz")) {
            SEXP tmp = eval(lang2(
                install("thisPathInZipFileError"),
                mkString("'this.path' cannot be used within a zip file")
            ), rho);
            INCREMENT_NAMED(tmp);
            defineVar(install("__this.path::for msg__"), tmp, frame);
        }
        else {
            SEXP tmp = eval(lang3(
                install("thisPathUnrecognizedConnectionClassError"),
                mkString("'this.path' not implemented when source-ing a connection of class "),
                mkString(Class)
            ), rho);
            INCREMENT_NAMED(tmp);
            defineVar(install("__this.path::for msg__"), tmp, frame);
        }
    }
    defineVar(install("not.yet"), ScalarLogical(FALSE), rho);
    return;
}


SEXP findfiletheneval(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    int nprotect = 0;
    const char *name = "expr";


    int character_only, file_only;


    character_only = asLogical(CADDR(args));
    if (character_only == NA_LOGICAL)
        error(_("invalid '%s' argument"), "character.only");
    file_only = asLogical(CADDR(args));
    if (file_only == NA_LOGICAL)
        error(_("invalid '%s' argument"), "file.only");


    SEXP promise = findVarInFrame(rho, install(name));
    if (promise == R_UnboundValue) {
        const char *format = _("object '%s' not found");
        char str[strlen(format) + strlen(name) + 1];
        sprintf(str, format, name);
        error("%s; should never happen, please report!", str);
    }
    if (TYPEOF(promise) != PROMSXP)
        error("invalid '%s', must be a promise; should never happen, please report!", name);


    SEXP promises = R_NilValue;
    PROTECT_INDEX indx;
    PROTECT_WITH_INDEX(promises, &indx); nprotect++;


    /* we will be modifying the PRSEEN values of the promises,
     * but we need to change them to 0 or 2 depending upon whether
     * this returns a value as normal or the promises get interupted
     *
     * save the root promise, the original code of the promise,
     * and make an on.exit() call that will restore said promise
     */
    defineVar(install("promises"), promises, rho);
    eval(lang2(
        install("on.exit"),
        lang2(
            install(".External2"),
            install("C_setprseen2")
        )
    ), rho);


#define check_validity                                         \
    do {                                                       \
        if (PRVALUE(promise) != R_UnboundValue)                \
            error("invalid '%s', must be a call when '%s' is missing", name, "file");\
        REPROTECT(promises = CONS(promise, promises), indx);   \
        if (PRSEEN(promise)) {                                 \
            if (PRSEEN(promise) == 1)                          \
                error(_("promise already under evaluation: recursive default argument reference or earlier problems?"));\
            else {                                             \
                SET_PRSEEN(promise, 1);                        \
                warning(_("restarting interrupted promise evaluation"));\
            }                                                  \
        }                                                      \
        else SET_PRSEEN(promise, 1);                           \
    } while (0)


#define set_prvalues_then_return(val)                          \
    do {                                                       \
        for (SEXP x = promises ; x != R_NilValue ; x = CDR(x)) {\
            SEXP p = CAR(x);                                   \
            SET_PRSEEN (p, 0);                                 \
            SET_PRVALUE(p, (val));                             \
            ENSURE_NAMEDMAX((val));                            \
            SET_PRENV  (p, R_NilValue);                        \
        }                                                      \
        /* remove the previous on.exit() */                    \
        eval(lang1(install("on.exit")), rho);                  \
        UNPROTECT(nprotect);                                   \
        return (val);                                          \
    } while (0)


    check_validity;


    /* find the root promise */
    while (TYPEOF(PREXPR(promise)) == PROMSXP) {
        promise = PREXPR(promise);
        check_validity;
    }


    SEXP expr = PREXPR(promise),
         env  = PRENV (promise);


    if (TYPEOF(expr) != LANGSXP)
        error("invalid '%s', must be a call when '%s' is missing", name, "file");


    if (length(expr) < 2) {
        SEXP val = eval(PRCODE(promise), env);
        set_prvalues_then_return(val);
    }


    SEXP oexpr = expr;
    expr = duplicate(expr);
    PROTECT(expr); nprotect++;


    SEXP fun     = CAR(expr),
         funargs = CDR(expr);
    if (TYPEOF(fun) == SYMSXP)
        fun = findFun3(fun, env, expr);
    else
        fun = eval(fun, env);
    PROTECT(fun); nprotect++;


    switch (TYPEOF(fun)) {
    case SPECIALSXP:
    case BUILTINSXP:
    case CLOSXP:
        break;
    default:
        error(_("attempt to apply non-function"));
    }


    /* change the function so that it is not evaluated twice */
    SETCAR(expr, fun);


    SEXP s, b, dots, dot;
    int already_checked_dots;


    SEXP tag;
    if (TYPEOF(fun) == CLOSXP)
        tag = TAG(FORMALS(fun));
    else
        tag = R_NilValue;


    int i, n = -1;


    if (tag != R_NilValue && tag != R_DotsSymbol) {


        s = NULL;
        dots = NULL;
        /* exact matches */
        already_checked_dots = 0;
        for (b = funargs, i = 0 ; b != R_NilValue ; b = CDR(b), i++) {
            if (CAR(b) == R_DotsSymbol) {
                if (already_checked_dots)
                    continue;
                already_checked_dots = 1;
                dots = findVar(R_DotsSymbol, env);
                if (TYPEOF(dots) == DOTSXP) {
                    for (dot = dots ; dot != R_NilValue ; dot = CDR(dot)) {
                        if (TAG(dot) != R_NilValue && pmatch(tag, TAG(dot), 1)) {
                            if (s != NULL)
                                errorcall(oexpr, _("formal argument \"%s\" matched by multiple actual arguments"), CHAR(PRINTNAME(tag)));
                            else
                                s = CAR(dot);
                            if (TYPEOF(s) != PROMSXP)
                                error(_("value in '...' is not a promise"));
                        }
                    }
                }
                else if (dots != R_NilValue && dots != R_MissingArg)
                    error(_("'...' used in an incorrect context"));
            }
            else if (TAG(b) != R_NilValue && pmatch(tag, TAG(b), 1)) {
                if (s != NULL)
                    errorcall(oexpr, _("formal argument \"%s\" matched by multiple actual arguments"), CHAR(PRINTNAME(tag)));
                else
                    s = CAR(b);
                n = i;
            }
        }


        if (s == NULL) {
            /* partial matches */
            already_checked_dots = 0;
            for (b = funargs, i = 0 ; b != R_NilValue ; b = CDR(b), i++) {
                if (CAR(b) == R_DotsSymbol) {
                    if (already_checked_dots)
                        continue;
                    already_checked_dots = 1;
                    if (TYPEOF(dots) == DOTSXP) {
                        for (dot = dots ; dot != R_NilValue ; dot = CDR(dot)) {
                            if (TAG(dot) != R_NilValue && pmatch(tag, TAG(dot), 0)) {
                                if (s != NULL)
                                    errorcall(oexpr, _("formal argument \"%s\" matched by multiple actual arguments"), CHAR(PRINTNAME(tag)));
                                else
                                    s = CAR(dot);
                                if (TYPEOF(s) != PROMSXP)
                                    error(_("value in '...' is not a promise"));
                            }
                        }
                    }
                    else if (dots != R_NilValue && dots != R_MissingArg)
                        error(_("'...' used in an incorrect context"));
                }
                else if (TAG(b) != R_NilValue && pmatch(tag, TAG(b), 0)) {
                    if (s != NULL)
                        errorcall(oexpr, _("formal argument \"%s\" matched by multiple actual arguments"), CHAR(PRINTNAME(tag)));
                    else
                        s = CAR(b);
                    n = i;
                }
            }
        }


        if (s == NULL) {
            /* first untagged argument */
            already_checked_dots = 0;
            for (b = funargs, i = 0 ; b != R_NilValue ; b = CDR(b), i++) {
                if (CAR(b) == R_DotsSymbol) {
                    if (already_checked_dots)
                        continue;
                    already_checked_dots = 1;
                    if (TYPEOF(dots) == DOTSXP) {
                        for (dot = dots ; dot != R_NilValue ; dot = CDR(dot)) {
                            if (TAG(dot) == R_NilValue) {
                                s = CAR(dot);
                                if (TYPEOF(s) != PROMSXP)
                                    error(_("value in '...' is not a promise"));
                                break;
                            }
                        }
                        if (s != NULL) break;  /* break out of both for loops */
                    }
                    else if (dots != R_NilValue && dots != R_MissingArg)
                        error(_("'...' used in an incorrect context"));
                }
                else if (TAG(b) == R_NilValue) {
                    s = CAR(b);
                    n = i;
                    break;
                }
            }
        }
    }
    else {
        s = NULL;
        dots = NULL;
        already_checked_dots = 0;
        for (b = funargs, i = 0 ; b != R_NilValue ; b = CDR(b), i++) {
            if (CAR(b) == R_DotsSymbol) {
                if (already_checked_dots)
                    continue;
                already_checked_dots = 1;
                dots = findVar(R_DotsSymbol, env);
                if (TYPEOF(dots) == DOTSXP) {
                    s = CAR(dots);
                    if (TYPEOF(s) != PROMSXP)
                        error(_("value in '...' is not a promise"));
                    break;
                }
                else if (dots != R_NilValue && dots != R_MissingArg)
                    error(_("'...' used in an incorrect context"));
            }
            else {
                s = CAR(b);
                n = i;
                break;
            }
        }
    }
    if (s == NULL) {
        if (character_only || file_only)
            errorcall(oexpr, "argument '%s' is missing", CHAR(PRINTNAME(tag)));
        SEXP tmp = eval(expr, env);
        set_prvalues_then_return(tmp);
    }


    SEXP e;


    switch (TYPEOF(s)) {
    case PROMSXP:
        e = eval(s, env);
        break;
    case SYMSXP:
    case LANGSXP:
        if (n == -1)
            error("found a symbol / / call but not an index; should never happen, please report!");
        e = eval(s, env);


        SEXP aenv = R_NewEnv(R_EmptyEnv, TRUE, 1);
        PROTECT(aenv); nprotect++;


        SEXP tmp = lang5(
            findVarInFrame(R_BaseEnv, install("delayedAssign")),
            mkString("x"),
            R_NilValue,
            R_EmptyEnv,
            aenv
        );
        PROTECT(tmp); nprotect++;


        eval(tmp, R_EmptyEnv);
        tmp = findVarInFrame(aenv, install("x"));
        SET_PRCODE(tmp, s);
        SET_PRSEEN(tmp, 0);
        SET_PRVALUE(tmp, e);
        ENSURE_NAMEDMAX(e);
        SET_PRENV(tmp, R_NilValue);


        e = tmp;
        /* add 1 for the function at the start */
        SETCAR(nthcdr(expr, n + 1), e);
        break;
    default:
        e = s;
        break;
    }


    validatefile(TYPEOF(e) == PROMSXP ? PRVALUE(e) : e, rho, character_only, file_only, rho);
    SEXP tmp = eval(expr, env);
    set_prvalues_then_return(tmp);
}


SEXP do_wrapsource(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    defineVar(install("not.yet"), ScalarLogical(TRUE), rho);


    SEXP file;
    int character_only, file_only;


    int nargs = length(args) - 1;
    switch (nargs) {
    case 2:
        return findfiletheneval(call, op, args, rho);
    case 3:
        file = CADR(args);
        character_only = asLogical(CADDR(args));
        if (character_only == NA_LOGICAL)
            error(_("invalid '%s' argument"), "character.only");
        file_only = asLogical(CADDR(args));
        if (file_only == NA_LOGICAL)
            error(_("invalid '%s' argument"), "file.only");
        validatefile(file, rho, character_only, file_only, rho);
        return eval(install("expr"), rho);
    default:
        error(
            nargs == 1 ? "%d argument passed to .External(%s) which requires %s" :
                         "%d arguments passed to .External(%s) which requires %s",
            nargs, "C_wrapsource", "2 or 3"
        );
    }


    return R_NilValue;
}
