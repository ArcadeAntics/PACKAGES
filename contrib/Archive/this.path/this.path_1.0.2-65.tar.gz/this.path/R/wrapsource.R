wrap.source <- function (expr, file, character.only = FALSE, file.only = FALSE)
{
    if (missing(expr))
        expr
    if (missing(file))
        .External2(C_wrapsource, character.only, file.only)
    else .External2(C_wrapsource, file, character.only, file.only)
}
