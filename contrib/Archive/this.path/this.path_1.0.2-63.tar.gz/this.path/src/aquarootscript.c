#include <R.h>
#include <Rinternals.h>


#if defined(__APPLE__) && defined(__MACH__)
    #include <Cocoa/Cocoa.h>
    extern const char *getRootScript();
#else
    const char *getRootScript()
    {
        return NULL;
    }
#endif





SEXP do_aquarootscript(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    errorcall(call, "not implemented yet");
    return R_NilValue;
}
