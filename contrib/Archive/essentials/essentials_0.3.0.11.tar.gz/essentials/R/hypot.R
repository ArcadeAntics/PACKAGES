hypot <- function (..., na.rm = FALSE)
.External2(C_hypot, na.rm)


phypot <- function (..., na.rm = FALSE)
.External2(C_phypot, na.rm)
