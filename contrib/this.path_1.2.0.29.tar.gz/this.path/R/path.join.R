windows.path.join <- function (...)
.External2(C_windowspathjoin)


unix.path.join <- function (...)
.External2(C_unixpathjoin)


path.join <- function (...)
.External2(C_pathjoin)
