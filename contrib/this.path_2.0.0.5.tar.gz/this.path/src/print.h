#ifndef R_THIS_PATH_PRINT
#define R_THIS_PATH_PRINT


#include <Rinternals.h>       /* need definition of SEXP */


extern void my_PrintValueEnv(SEXP s, SEXP env);


#endif /* R_THIS_PATH_PRINT */
