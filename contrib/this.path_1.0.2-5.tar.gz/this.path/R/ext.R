# path.splitext <- function (path)
# {
#     value <- matrix("", 2L, length(path), dimnames = list(c("root", "ext"), names(path)))
#     b <- basename2(path)
#     m <- regmatches(b, regexec("^(.*[^.].*)(\\.[^.]+)(\\.(gz|bz2|xz|tgz))?$", b))
#     i <- lengths(m) > 0L
#     value[1L, i] <- path.join(dirname2(path[i]), vapply(m[i], `[[`, 2L, FUN.VALUE = ""))
#     value[2L, i] <- vapply(m[i], `[[`, 3L, FUN.VALUE = "")
#     value[1L, !i] <- path[!i]
#     value
# }
#
#
# path.splitext(c(a = "C:test\\testing2.jpg/", b = "testing.tar.gz"))
