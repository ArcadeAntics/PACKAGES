##
## this.path : Get Executing Script's Path
## Copyright (C) 2023-2024   Iris Simmons
##


print(loadedNamespaces())


this.path:::.HAVE_AQUA
this.path:::.PATH_MAX
this.path:::.NAMEDMAX

this.path:::.mbcslocale
this.path:::.utf8locale
this.path:::.latin1locale
this.path:::.R_MB_CUR_MAX
