print(loadedNamespaces())


this.path:::.HAVE_AQUA
this.path:::.PATH_MAX
this.path:::.NAMEDMAX

this.path:::.mbcslocale
this.path:::.utf8locale
this.path:::.latin1locale
this.path:::.R_MB_CUR_MAX
