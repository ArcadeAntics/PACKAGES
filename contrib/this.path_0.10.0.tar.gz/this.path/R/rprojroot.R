#
#
# # we use a delayed assign so that 'rprojroot' is not automatically loaded
# delayedAssign("criterion", {
#     rprojroot::has_file(".here") | rprojroot::is_rstudio_project |
#         rprojroot::is_r_package | rprojroot::is_remake_project |
#         rprojroot::is_projectile_project | rprojroot::is_vcs_root
# })
#
#
# proj <- function (..., .. = 0L)
# {
#
# }
#
#
#
#
#
# here:::.onLoad
#     here:::do_refresh_here
#         here:::set_fix_fun
#         criterion$make_fix_file
#         rprojroot:::from_wd
#         rprojroot:::from_wd$make_fix_file
#             rprojroot:::make_fix_root_file
#                 rprojroot:::find_root
#                     rprojroot:::get_start_path
#
#
