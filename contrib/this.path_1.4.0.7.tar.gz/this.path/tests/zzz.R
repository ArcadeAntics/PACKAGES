this.path:::.libname
this.path:::.pkgname
this.path:::.libpath
this.path:::.HAVE_AQUA
this.path:::.PATH_MAX
this.path:::.NAMEDMAX
