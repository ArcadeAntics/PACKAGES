assign.in.place <- function (x, value)
.Call(C_assign.in.place, x, value)
