this.path:::libname
this.path:::pkgname
this.path:::libpath
this.path:::PATH_MAX
this.path:::HAVE_AQUA
