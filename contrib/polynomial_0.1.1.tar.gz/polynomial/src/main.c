#include <R.h>
#include <Rinternals.h>
#include <Rmath.h>





// replace an NA with 0 or 1
#define filter_na0(X) ((X == NA_INTEGER) ? 0 : X)
#define filter_na1(X) ((X == NA_INTEGER) ? 1 : X)





SEXP do_Bessel(SEXP n)
{
    int k, j, degree = asInteger(n);


    if (xlength(n) != 1)
        warning("first element used of '%s' argument", "n");
    if (degree == NA_INTEGER || degree < 0)
        error("'%s' must be a non-negative integer", "n");
    if (degree > 65535)
        error("'%s' too large", "n");


    SEXP value = PROTECT(allocVector(REALSXP, degree + 1));
    double tmp, *rvalue = REAL(value);


    for (k = 0; k < degree + 1; k++) {
        tmp = 1;
        for (j = 1; j <=     k; j++) tmp *= (degree - k + j)/((double) j);
        for (     ; j <= 2 * k; j++) tmp *= (degree - k + j)/2.0;
        rvalue[k] = tmp;
    }


    UNPROTECT(1);
    return value;
}


SEXP do_Chebyshev(SEXP n, double kind)
{
    int i, j, degree = asInteger(n);


    if (xlength(n) != 1)
        warning("first element used of '%s' argument", "n");
    if (degree == NA_INTEGER || degree < 0)
        error("'%s' must be a non-negative integer", "n");
    if (degree > 65535)
        error("'%s' too large", "n");


    int len = degree + 1;
    SEXP value = PROTECT(allocVector(REALSXP, len));
    double *rvalue = REAL(value);


    if (degree == 0) {
        rvalue[0] = 1;
    }
    else if (degree == 1) {
        rvalue[0] = 0;
        rvalue[1] = kind;
    }
    else {
        int even = degree % 2;  // do we loop an even number of times?
        double tmp[len];
        Memzero(rvalue, len);
        Memzero(tmp, len);
        if (even) {
            tmp[0] = 1;
            rvalue[1] = kind;
        }
        else {
            rvalue[0] = 1;
            tmp[1] = kind;
        }
        for (i = 2; i <= degree; i++) {
            if (even) {
                tmp[0] *= -1;  // tmp[0] = -tmp[0];
                for (j = 1; j <= i - 2; j++)
                    tmp[j] = 2 * rvalue[j - 1] - tmp[j];
                tmp[i - 1] = 2 * rvalue[i - 2];
                tmp[i    ] = 2 * rvalue[i - 1];
            }
            else {
                rvalue[0] *= -1;  // rvalue[0] = -rvalue[0];
                for (j = 1; j <= i - 2; j++)
                    rvalue[j] = 2 * tmp[j - 1] - rvalue[j];
                rvalue[i - 1] = 2 * tmp[i - 2];
                rvalue[i    ] = 2 * tmp[i - 1];
            }
            even = !even;
        }
    }


    UNPROTECT(1);
    return value;
}


SEXP do_Chebyshev1(SEXP n)
{
    return do_Chebyshev(n, 1);
}


SEXP do_Chebyshev2(SEXP n)
{
    return do_Chebyshev(n, 2);
}


SEXP do_Hermite(SEXP n)
{
    int i, j, degree = asInteger(n);


    if (xlength(n) != 1)
        warning("first element used of '%s' argument", "n");
    if (degree == NA_INTEGER || degree < 0)
        error("'%s' must be a non-negative integer", "n");
    if (degree > 65535)
        error("'%s' too large", "n");


    SEXP value = PROTECT(allocVector(REALSXP, degree + 1));
    double *rvalue = REAL(value);


    // first we populate 'rvalue' with the coefficients
    // of the 0-th order hermite polynomial
    //
    // 1 at the first position, 0 in all the rest
    Memzero(rvalue, degree + 1);
    rvalue[0] = 1.0;


    // from the (i-1)-th hermite polynomial coefficients,
    // calculate the i-th hermite polynomial coefficients
    for (i = 1; i <= degree; i++) {
        memmove(rvalue + 1, rvalue, i * sizeof(double));
        rvalue[0] = 0.0;
        for (j = 2; j <= i; j++)
            rvalue[j - 2] -= (j - 1) * rvalue[j];
    }


    // a warning message for non-finite coefficients
    for (i = 0; i < degree + 1; i++) {
        if (!R_FINITE(rvalue[i])) {
            warning("non-finite coefficients produced");
            break;
        }
    }


    UNPROTECT(1);
    return value;
}





int _gcd(int x, int y)
{
    if (x == y) {
        return x;
    }
    else if (x % 2 == 0) {
        if (y % 2 == 0)
            return 2 * _gcd(x/2, y/2);
        else return _gcd(x/2, y);
    }
    else if (y % 2 == 0) {
        return _gcd(x, y/2);
    }
    else if (x > y) {
        return _gcd((x - y)/2, y);
    }
    else return _gcd((y - x)/2, x);
}


double _fgcd(double x, double y)
{
    if (x == y) {
        return x;
    }
    else if (fmod(x, 2.0) == 0) {
        if (fmod(y, 2.0) == 0)
            return 2 * _gcd(x/2, y/2);
        else return _gcd(x/2, y);
    }
    else if (fmod(y, 2.0) == 0) {
        return _gcd(x, y/2);
    }
    else if (x > y) {
        return _gcd((x - y)/2, y);
    }
    else return _gcd((y - x)/2, x);
}


int gcd(int x, int y)
{
    if (x == NA_INTEGER || y == NA_INTEGER) return NA_INTEGER;
    x = abs(x), y = abs(y);
    if (x == 0) return y;
    if (y == 0) return x;
    return _gcd(x, y);
}


double fgcd(double x, double y)
{
    if (ISNA(x) || ISNA(y))
        return NA_REAL;
    if (!R_FINITE(x) || !R_FINITE(y))
        return R_NaN;
    x = fabs(trunc(x)); y = fabs(trunc(y));
    if (x == 0.0) return y;
    if (y == 0.0) return x;
    return _fgcd(x, y);
}


int lcm(int x, int y)
{
    if (x == NA_INTEGER || y == NA_INTEGER) return NA_INTEGER;
    if (x == 0 || y == 0) return 0;
    x = abs(x), y = abs(y);
    double value = ((double) x) / gcd(x, y) * ((double) y);
    if (value > INT_MAX) return NA_INTEGER;
    return (int) value;
}


int coprime(int x, int y)
{
    int value = gcd(x, y);
    if (value == NA_INTEGER) return NA_LOGICAL;
    return value == 1;
}





SEXP do_pgcd(SEXP args)
{
    SEXP a, x;
    R_xlen_t i, n, len = 1;
    int na_rm;

    args = CDR(args);
    na_rm = asLogical(CAR(args));
    args = CDR(args);

    if (args == R_NilValue) return allocVector(INTSXP, 0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        case NILSXP:
        case REALSXP:
        case CPLXSXP:
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF((x))));
            return R_NilValue;
        }
        if (len) {
            n = xlength(x);
            if (n == 0 || n > len)
                len = n;
        }
    }

    if (len == 0) return allocVector(INTSXP, 0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        if (len % xlength(CAR(a))) {
            warning("an argument will be fractionally recycled");
            break;
        }
    }

    SEXP value = PROTECT(allocVector(INTSXP, len));
    int *ivalue = INTEGER(value);
    Memzero(ivalue, len);
    // memset(ivalue, 0, len * sizeof(int));

    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        n = xlength(x);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
            break;
        case REALSXP:
        case CPLXSXP:
            x = coerceVector(x, INTSXP);
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
        int *ix = INTEGER(x);
        if (n == 1) {
            int x1 = ix[0];

            if (na_rm && x1 == NA_INTEGER)
                x1 = 0;

            for (i = 0; i < len; i++) {
                ivalue[i] = gcd(ivalue[i], x1);
            }
        }
        else if (n == len) {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    ivalue[i] = gcd(ivalue[i], filter_na0(ix[i]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    ivalue[i] = gcd(ivalue[i], ix[i]);
                }
            }
        }
        else {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    ivalue[i] = gcd(ivalue[i], filter_na0(ix[i % len]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    ivalue[i] = gcd(ivalue[i], ix[i % len]);
                }
            }
        }
    }

    for (a = args; a != R_NilValue; a = CDR(a)) {

        x = CAR(a);
        // the argument must be the same length as 'value' in
        // order to copy 'dim', 'dimnames' and 'names' attributes
        if (xlength(x) == len) {

            // if 'value' does not have a 'dim' attribute
            if (getAttrib(value, R_DimSymbol) == R_NilValue) {

                // if 'value' does not have a 'dim' attribute
                // and 'x' has a 'dim' attribute
                if (getAttrib(x, R_DimSymbol) != R_NilValue) {
                    setAttrib(value, R_DimSymbol, getAttrib(x, R_DimSymbol));
                    setAttrib(value, R_NamesSymbol, R_NilValue);

                    // if 'a' also has a 'dimnames' attribute,
                    // copy them and immediately return 'value'
                    if (getAttrib(x, R_DimNamesSymbol) != R_NilValue) {
                        setAttrib(value, R_DimNamesSymbol, getAttrib(x, R_DimNamesSymbol));
                        UNPROTECT(1);
                        return value;
                    }
                }
                else if (getAttrib(value, R_NamesSymbol) == R_NilValue &&
                    getAttrib(x, R_NamesSymbol) != R_NilValue) {
                    setAttrib(value, R_NamesSymbol, getAttrib(x, R_NamesSymbol));
                }
            }
            else if (conformable(value, x)) {
                if (getAttrib(x, R_DimNamesSymbol) != R_NilValue) {
                    setAttrib(value, R_DimNamesSymbol, getAttrib(x, R_DimNamesSymbol));
                    UNPROTECT(1);
                    return value;
                }
            }
        }
    }

    UNPROTECT(1);
    return value;
}


// n-dimensional gcd
SEXP do_gcd(SEXP args)
{
    SEXP a, x;
    R_xlen_t i, n;
    int na_rm;

    args = CDR(args);
    na_rm = asLogical(CAR(args)), args = CDR(args);

    if (args == R_NilValue) return ScalarInteger(0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        case NILSXP:
        case REALSXP:
        case CPLXSXP:
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
    }

    int value = 0;
    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        n = xlength(x);

        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
            break;
        case NILSXP:
            continue;
        case REALSXP:
        case CPLXSXP:
            x = coerceVector(x, INTSXP);
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return ScalarInteger(NA_INTEGER);
        }
        int *ix = INTEGER(x);
        if (na_rm) {
            for (i = 0; i < n; i++) {
                value = gcd(value, filter_na0(ix[i]));
            }
        }
        else {
            for (i = 0; i < n; i++) {
                value = gcd(value, ix[i]);
            }
        }
    }
    return ScalarInteger(value);
}





SEXP do_plcm(SEXP args)
{
    SEXP a, x;
    R_xlen_t i, n, len = 1;
    int na_rm;

    args = CDR(args);
    na_rm = asLogical(CAR(args));
    args = CDR(args);

    if (args == R_NilValue) return allocVector(INTSXP, 0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        case NILSXP:
        case REALSXP:
        case CPLXSXP:
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF((x))));
            return R_NilValue;
        }
        if (len) {
            n = xlength(x);
            if (n == 0 || n > len)
                len = n;
        }
    }

    if (len == 0) return allocVector(INTSXP, 0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        if (len % xlength(CAR(a))) {
            warning("an argument will be fractionally recycled");
            break;
        }
    }

    SEXP value = PROTECT(allocVector(INTSXP, len));
    int *ivalue = INTEGER(value);
    for (i = 0; i < len; i++) ivalue[i] = 1;

    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        n = xlength(x);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
            break;
        case REALSXP:
        case CPLXSXP:
            x = coerceVector(x, INTSXP);
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
        int *ix = INTEGER(x);
        if (n == 1) {
            int x1 = ix[0];

            if (na_rm && x1 == NA_INTEGER)
                x1 = 1;

            for (i = 0; i < len; i++) {
                ivalue[i] = lcm(ivalue[i], x1);
            }
        }
        else if (n == len) {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    ivalue[i] = lcm(ivalue[i], filter_na1(ix[i]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    ivalue[i] = lcm(ivalue[i], ix[i]);
                }
            }
        }
        else {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    ivalue[i] = lcm(ivalue[i], filter_na1(ix[i % len]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    ivalue[i] = lcm(ivalue[i], ix[i % len]);
                }
            }
        }
    }

    for (a = args; a != R_NilValue; a = CDR(a)) {

        x = CAR(a);
        // the argument must be the same length as 'value' in
        // order to copy 'dim', 'dimnames' and 'names' attributes
        if (xlength(x) == len) {

            // if 'value' does not have a 'dim' attribute
            if (getAttrib(value, R_DimSymbol) == R_NilValue) {

                // if 'value' does not have a 'dim' attribute
                // and 'x' has a 'dim' attribute
                if (getAttrib(x, R_DimSymbol) != R_NilValue) {
                    setAttrib(value, R_DimSymbol, getAttrib(x, R_DimSymbol));
                    setAttrib(value, R_NamesSymbol, R_NilValue);

                    // if 'a' also has a 'dimnames' attribute,
                    // copy them and immediately return 'value'
                    if (getAttrib(x, R_DimNamesSymbol) != R_NilValue) {
                        setAttrib(value, R_DimNamesSymbol, getAttrib(x, R_DimNamesSymbol));
                        UNPROTECT(1);
                        return value;
                    }
                }
                else if (getAttrib(value, R_NamesSymbol) == R_NilValue &&
                    getAttrib(x, R_NamesSymbol) != R_NilValue) {
                    setAttrib(value, R_NamesSymbol, getAttrib(x, R_NamesSymbol));
                }
            }
            else if (conformable(value, x)) {
                if (getAttrib(x, R_DimNamesSymbol) != R_NilValue) {
                    setAttrib(value, R_DimNamesSymbol, getAttrib(x, R_DimNamesSymbol));
                    UNPROTECT(1);
                    return value;
                }
            }
        }
    }

    UNPROTECT(1);
    return value;
}


// n-dimensional lcm
SEXP do_lcm(SEXP args)
{
    SEXP a, x;
    R_xlen_t i, n;
    int na_rm;

    args = CDR(args);
    na_rm = asLogical(CAR(args)), args = CDR(args);

    if (args == R_NilValue) return ScalarInteger(1);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        case NILSXP:
        case REALSXP:
        case CPLXSXP:
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
    }

    int value = 1;
    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        n = xlength(x);

        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
            break;
        case NILSXP:
            continue;
        case REALSXP:
        case CPLXSXP:
            x = coerceVector(x, INTSXP);
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return ScalarInteger(NA_INTEGER);
        }
        int *ix = INTEGER(x);
        if (na_rm) {
            for (i = 0; i < n; i++) {
                value = lcm(value, filter_na1(ix[i]));
            }
        }
        else {
            for (i = 0; i < n; i++) {
                value = lcm(value, ix[i]);
            }
        }
    }
    return ScalarInteger(value);
}





static const R_CallMethodDef callRoutines[] = {
    {"Bessel"    , (DL_FUNC) &do_Bessel    , 1},
    {"Chebyshev1", (DL_FUNC) &do_Chebyshev1, 1},
    {"Chebyshev2", (DL_FUNC) &do_Chebyshev2, 1},
    {"Hermite"   , (DL_FUNC) &do_Hermite   , 1},
    {NULL, NULL, 0}
};


static const R_ExternalMethodDef externalRoutines[] = {
    {"gcd" , (DL_FUNC) &do_gcd , -1},
    {"pgcd", (DL_FUNC) &do_pgcd, -1},
    {"lcm" , (DL_FUNC) &do_lcm , -1},
    {"plcm", (DL_FUNC) &do_plcm, -1},
    {NULL, NULL, 0}
};


void R_init_polynomial(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, callRoutines, NULL, externalRoutines);
    R_useDynamicSymbols(dll, FALSE);
    R_forceSymbols(dll, TRUE);
}
