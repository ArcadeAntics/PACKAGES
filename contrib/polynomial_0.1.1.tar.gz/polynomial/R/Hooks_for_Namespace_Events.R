.onUnload <- function (libpath)
{
    library.dynam.unload("polynomial", libpath)
}
