#include <R.h>
#include <Rinternals.h>





const char * point_to_pathspec(const char *s, int nchar)
{
    /* there are three types of absolute paths in windows
     *
     * there are those beginning with d:/ or some other letter
     * we call these drives
     *
     * there are those beginning with //host/share
     * we call these network shares (for accessing remote data)
     *
     * and specifically for R, there are those beginning with ~
     * for functions such as dirname() and basename(), we would normally expand
     * those filenames with R_ExpandFileName(), but for path.join() we don't
     * want to modify the inputs
     *
     * unlike unix, a path beginning with / is NOT an absolute path.
     * try this for yourself:

setwd("C:/")
normalizePath("/path/to/file")

setwd("D:/")
normalizePath("/path/to/file")

     * which should do something like this:

> setwd("C:/")
> normalizePath("/path/to/file")
[1] "C:\\path\\to\\file"
>
> setwd("D:/")
> normalizePath("/path/to/file")
[1] "D:\\path\\to\\file"
>

     * this function will return the width of the drive specification of the
     * path, or 0 if no drive specification exists or is invalid
     *
     * when I say drive specification, I am referring to all three of the above
     * d:           is a drive specification
     * //host/share is a drive specification
     * ~            is a drive specification
     *
     * as a short-form, you can call it a drivespec
     *
     * the path specification of a path is the portion of the string
     * immediately following a possible drivespec
     *
     * you can call it a pathspec for short
     *
     *
     *
     * Arguments:
     *
     * s
     *
     *     the string in which we are looking for a drivespec
     *
     * nchar
     *
     *     the length of the string. this argument exists purely so that you
     *     don't have to calculate strlen(s) twice (assuming you're using nchar
     *     somewhere else in your program)
     */


    if (nchar <= 0)
        return s;
    if (nchar >= 2 && *(s + 1) == ':')  /* s starts with d: or similar */
        return s + 2;
    if (*s == '~' &&      /* s starts with ~ */
        (
            nchar == 1       ||  /* s is exactly ~ */
            *(s + 1) == '/'  ||  /* s starts with ~/ */
            *(s + 1) == '\\'     /* s starts with ~\ */
        ))
    {
        return s + 1;
    }


    /* 5 characters is the minimum required for a network share
     * the two slashes at the start, at least one for the host name,
     * a slash between the host name and share name,
     * and at least one for the share name
     */
    if (nchar < 5)
        return s;


    const char *ptr = s;
    if (*ptr != '/' && *ptr != '\\')  /* first character must be / or \ */
        return s;
    ptr++;
    if (*ptr != '/' && *ptr != '\\')  /* second character must be / or \ */
        return s;
    ptr++;


    /* third character must NOT be / or \
     * this is the start of the host name of the network share
     */
    if (*ptr == '/' || *ptr == '\\')
        return s;


    const char *ptr_slash, *ptr_backslash;
    ptr_slash     = strchr(ptr, '/');
    ptr_backslash = strchr(ptr, '\\');
    if (ptr_slash) {  /* slash was found */
        if (ptr_backslash) {  /* backslash was also found */
            if (ptr_slash < ptr_backslash)  /* slash found before backslash */
                ptr = ptr_slash;
            else ptr = ptr_backslash;  /* backslash found before slash */
        }
        else ptr = ptr_slash;  /* backslash was not found */
    }
    else {  /* slash was not found */
        if (ptr_backslash)  /* backslash was found */
            ptr = ptr_backslash;
        else return s;
    }
    ptr++;


    /* look for a non-slash and non-backslash character
     * this is the start of the share name of the network path
     */
    int found_share_name = 0;


    /* the condition *ptr can be also written as *ptr != '\0',
     * which is to say that ptr does NOT point to the end of the string
     * using *ptr is simply shorter
     */
    for (; *ptr; ptr++) {
        if (*ptr != '/' && *ptr != '\\') {
            found_share_name = 1;
            break;
        }
    }
    if (!found_share_name) return s;


    /* again, look for a slash or backslash */
    ptr_slash     = strchr(ptr, '/');
    ptr_backslash = strchr(ptr, '\\');
    if (ptr_slash) {  /* slash was found */
        if (ptr_backslash) {  /* backslash was also found */
            if (ptr_slash < ptr_backslash)  /* slash found before backslash */
                return ptr_slash;
            else return ptr_backslash;  /* backslash found before slash */
        }
        else return ptr_slash;  /* backslash was not found */
    }
    else {  /* slash was not found */
        if (ptr_backslash)  /* backslash was found */
            return ptr_backslash;
        else return s + nchar;
    }
}


const char * point_to_pathspec_unix(const char *s, int nchar)
{
    /* similar to the above get_drive_width() but specifically for unix,
     * where a drivespec only really makes sense in terms of a network share
     */


    /* 5 characters is the minimum required for a network share
     * the two slashes at the start, at least one for the host name,
     * a slash between the host name and share name,
     * and at least one for the share name
     */
    if (nchar < 5)
        return s;


    const char *ptr = s;
    if (*ptr != '/')  /* first character must be / */
        return s;
    ptr++;
    if (*ptr != '/')  /* second character must be / */
        return s;
    ptr++;


    /* third character must NOT be /
     * this is the start of the host name of the network share
     */
    if (*ptr == '/')
        return s;


    const char *ptr_slash;
    ptr_slash = strchr(ptr, '/');
    if (ptr_slash)  /* slash was found */
        ptr = ptr_slash;
    else return s;
    ptr++;


    /* look for a non-slash character
     * this is the start of the share name of the network share
     */
    int found_share_name = 0;


    for (; *ptr; ptr++) {
        if (*ptr != '/') {
            found_share_name = 1;
            break;
        }
    }
    if (!found_share_name) return s;


    /* again, look for a slash */
    ptr_slash = strchr(ptr, '/');
    if (ptr_slash)  /* slash was found */
        return ptr_slash;
    else return s + nchar;
}


int isabs(const char *s, int nchar)
{
    if (!nchar) return 0;
    if (*s == '/') return 1;
    if (*s == '~') {
        if (nchar == 1) return 1;
        if (*(s + 1) == '/') return 1;
        return *R_ExpandFileName(s) == '/';
    }
    return 0;
}


SEXP do_test(SEXP call, SEXP op, SEXP args, SEXP rho)
{
    SEXP path = CADR(args);
    if (!isString(path))
        error("a character vector argument expected");


    int n = LENGTH(path);
    for (int i = 0; i < n; i++) {
        const char *ptr = translateCharUTF8(STRING_ELT(path, i));
        int nchar = strlen(ptr);
        const char *pathspec = point_to_pathspec(ptr, nchar);
        const char *expanded = R_ExpandFileName(ptr);
        Rprintf("string %d: %s\n", i + 1, ptr);
        Rprintf("pathspec: %s\n", pathspec);
        Rprintf("expanded: %s\n", expanded);
        Rprintf("string == pathspec: %s\n", ptr == pathspec ? "TRUE" : "FALSE");
        Rprintf("string == expanded: %s\n", ptr == expanded ? "TRUE" : "FALSE");
        Rprintf("isabs(string): %s\n", isabs(ptr, nchar) ? "TRUE" : "FALSE");
        Rprintf("\n");
    }


    return R_NilValue;
}
